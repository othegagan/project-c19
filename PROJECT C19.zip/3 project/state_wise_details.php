<?php require"connection.php";
?>

<!doctype html>
<html lang="en">

<head>
    <title>Covid - StateWise Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/favicon2.ico" type="image/x-icon">

    <!-- <meta name="theme-color" content="#6f42c1"> -->
    <!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	
    <!-- Bootstrap CDN links -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/jquery.fancybox.min.css">
	<link rel="stylesheet" href="css/aos.css">

    <!-- Custom Style sheet -->
	<link rel="stylesheet" href="css/style.css">


</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


    <div id="overlayer"></div>
	<div class="loader row flex-column align-items-center align-content-center">
        <div class="spinner-border text-primary" role="status"> </div>
        <h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
		<p class="mt-0">Loading...</p>
	</div>

    <div class="site-wrap">

        <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>


        <!-- header -->
        <?php require "header.php";?>


        <!-- main -->
        <div class="container-fluid">
        <h1>Corona Update</h1>

        <section class="corona_update container-fluid">
            <div class="mb-3 ">
                <div class="table-responsive mt-5">
                    <table class="table table-bordered table-striped text-centered table-hover" id="tbval">

                        <tr>
                            <th class="text-capitalize">lastupdatedtime</th>
                            <th class="text-capitalize">state</th>
                            <th class="text-capitalize">confirmed</th>
                            <th class="text-capitalize">active</th>
                            <th class="text-capitalize">recovered</th>
                            <th class="text-capitalize">new deaths</th>
                        </tr>

                        <?php

                        $data = file_get_contents('https://api.covid19india.org/data.json');
                        $coranalive = json_decode($data, true);

                        $statescount = count($coranalive['statewise']);

                        $i = 1;
                        while ($i < $statescount) {

                        ?>
                            <tr>

                                <td><?php echo $coranalive['statewise'][$i]['lastupdatedtime']  ?> </td>
                                <td><?php echo $coranalive['statewise'][$i]['state']  ?> </td>
                                <td><?php echo number_format($coranalive['statewise'][$i]['confirmed']  )?> </td>
                                <td><?php echo number_format($coranalive['statewise'][$i]['active'])  ?> </td>
                                <td><?php echo number_format($coranalive['statewise'][$i]['recovered'] ) ?> </td>
                                <td><?php echo number_format($coranalive['statewise'][$i]['deaths'])  ?> </td>

                            </tr>


                        <?php
                            $i++;
                        }
                        ?>
                    </table>
                </div>

            </div>



        </section>

    </div>


    
</div>
<!-- footer -->
<?php require "footer.php";?>

    </div> <!-- .site-wrap -->



    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>


    <script src="js/main.js"></script>


</body>

</html>