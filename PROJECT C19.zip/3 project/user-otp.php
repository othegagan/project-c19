<?php 

    require "connection.php";
    session_start();

    
    $email = "";
    $name = "";
    $errors = array();

    

    //if user click verification code submit button


        if(isset($_POST['check'])){
            $_SESSION['info'] = "";
            
            $otp_code = mysqli_real_escape_string($con, $_POST['otp']);
            $check_code = "SELECT * FROM usertable WHERE code = $otp_code";
            $code_res = mysqli_query($con, $check_code);
            
            if(mysqli_num_rows($code_res) > 0){
                $fetch_data = mysqli_fetch_assoc($code_res);
                $fetch_code = $fetch_data['code'];
                // $email = $fetch_data['email'];
                $code = 0;
                $status = 'verified';
                $update_otp = "UPDATE usertable SET code = $code, status = '$status' WHERE code = $fetch_code";
                $update_res = mysqli_query($con, $update_otp);
                if($update_res){
                    header('location: login.php');
                    exit();
                }else{
                    $errors['otp-error'] = "Failed while updating code!";
                }
            }else{
                $errors['otp-error'] = "You've entered incorrect code!";
            }
        }
    
    

?>

<!doctype html>
<html lang="en">

<head>
    <title>Covid - OTP verfication</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/favicon2.ico" type="image/x-icon">

    <!-- <meta name="theme-color" content="#6f42c1"> -->
    <!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	
    <!-- Bootstrap CDN links -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/jquery.fancybox.min.css">
	<link rel="stylesheet" href="css/aos.css">

    <!-- Custom Style sheet -->
	<link rel="stylesheet" href="css/style.css">

    <!-- page specifi style sheet -->
    <style>
        .container .form {
            background: #fff;
            border-radius: 5px;
            margin-left: -20px;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.075), 0 6px 20px 0 rgba(0, 0, 0, 0.075);
        }

        .container .form form .form-control {
            height: 40px;
            font-size: 15px;
        }

        .container .form form .forget-pass {
            margin: -15px 0 15px 0;
        }

        .container .form form .forget-pass a {
            font-size: 15px;
        }

        .container .form form .button {
            background: #6665ee;
            color: #fff;
            font-size: 17px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .container .form form .button:hover {
            background: #5757d1;
        }

        .container .form form .link {
            padding: 5px 0;
        }

        .container .form form .link a {
            color: #6665ee;
        }

        .container .login-form form p {
            font-size: 14px;
        }

        .container .row .alert {
            font-size: 14px;
        }
    </style>

</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


    <div id="overlayer"></div>
	<div class="loader row flex-column align-items-center align-content-center">
        <div class="spinner-border text-primary" role="status"> </div>
        <h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
		<p class="mt-0">Loading...</p>
	</div>

    
    <div class="site-wrap">

        <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close ">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>


         <!-- header -->
         <?php require "header.php";?>
        



        <div class="site-section pb-5 ">
            <div class="container  bg-2 ">
                <div class="myrow ml-0 pl-0 mt-4">
                    <div class=" col-lg-4 col-md-6 login-section-wrapper pl-3 pr-3 pb-3 form login-form">
                        <form action="user-otp.php" method="POST" autocomplete="">

                            <div>
                                <span class="text-center red"> &nbsp; Code Verification</span>
                            </div>
                                                <?php 
                                        if(isset($_SESSION['info'])){
                                            ?>
                                            <div class="alert alert-success text-center">
                                                <?php echo $_SESSION['info']; ?>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                        <?php
                                        if(count($errors) > 0){
                                            ?>
                                            <div class="alert alert-danger text-center">
                                                <?php
                                                foreach($errors as $showerror){
                                                    echo $showerror;
                                                }
                                                ?>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                <div class="form-group">
                                    <label>OTP</label>
                                    <input class="form-control" name="otp" placeholder="Enter your verification code" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="check" value="Submit"class="btn btn-primary btn-block font-weight-bold " > Verify
                                        </button>
                                    </div>
                                    
                        </form>
                        <p> You would be redirected to login page. Please login after verification </p>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- footer -->
    <?php require "footer.php";?>

    </div> <!-- .site-wrap -->

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>


    <script src="js/main.js"></script>


</body>

</html>