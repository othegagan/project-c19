<?php 

    require "connection.php";
    session_start();

    // Import PHPMailer classes into the global namespace
    // These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    
    // Load Composer's autoloader
    require 'vendor/autoload.php';
    
    $mail = new PHPMailer(true);

    //Server settings
    $mail->SMTPDebug = 0;                                       // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com;';  // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'projectcovid2@gmail.com';                     // SMTP username
    $mail->Password   = 'Covid19#';                               // SMTP password
    $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('projectcovid2@gmail.com', 'PROJECT C-19');

    // $file_name = $_FILES["file"]["name"];
    // move_uploaded_file($_FILES["file"]["tmp_name"], $file_name);
    // $mail->addAttachment($file_name);
    

    $email = "";
    $name = "";
    $errors = array();

    if (!isset($_SESSION['id']) ) {
        //if user signup button
        if(isset($_POST['signup'])){
            
            $name = mysqli_real_escape_string($con, $_POST['name']);
            $email = mysqli_real_escape_string($con, $_POST['email']);
            $password = mysqli_real_escape_string($con, $_POST['password']);
            $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

            if(trim(strlen($password)) < 8){
                $errors['password_char'] = "Password must be 8 characters long, so it should be strong";
            }

            if($password !== $cpassword){
                $errors['password'] = "Confirm password not matched!";
            }

            
            $email_check = "SELECT * FROM usertable WHERE email = '$email'";
            $res = mysqli_query($con, $email_check);
            if(mysqli_num_rows($res) > 0){
                $errors['email'] = "Email that you have entered is already exist!";
            }
            if(count($errors) === 0){
                $encpass = password_hash($password, PASSWORD_BCRYPT);
                $code = rand(999999, 111111);
                $status = "notverified";
                $insert_data = "INSERT INTO usertable (name, email, password, code, status)
                                values('$name', '$email', '$encpass', '$code', '$status')";
                $data_check = mysqli_query($con, $insert_data);
                if($data_check){
                    

                    $html='<!DOCTYPE html
                    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office"
                    style="width:100%;font-family:lato, helvetica, arial, sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0">
                
                <head>
                    <meta charset="UTF-8">
                    <meta content="width=device-width, initial-scale=1" name="viewport">
                    <meta name="x-apple-disable-message-reformatting">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <meta content="telephone=no" name="format-detection">
                    <title>New Template 2</title>
                    <!--[if (mso 16)]>
                    <style type="text/css">
                    a {text-decoration: none;}
                    </style>
                    <![endif]-->
                    <!--[if gte mso 9]><style>sup { font-size: 100% !important; }</style><![endif]-->
                    <!--[if gte mso 9]>
                    <xml>
                        <o:OfficeDocumentSettings>
                        <o:AllowPNG></o:AllowPNG>
                        <o:PixelsPerInch>96</o:PixelsPerInch>
                        </o:OfficeDocumentSettings>
                    </xml>
                    <![endif]-->
                        <!--[if !mso]><!-- -->
                        <link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i" rel="stylesheet">
                        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700,700i" rel="stylesheet">
                        <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
                        <!--<![endif]-->
                        <style type="text/css">
                            #outlook a {
                                padding: 0;
                            }
                        
                            .ExternalClass {
                                width: 100%;
                            }
                        
                            .ExternalClass,
                            .ExternalClass p,
                            .ExternalClass span,
                            .ExternalClass font,
                            .ExternalClass td,
                            .ExternalClass div {
                                line-height: 100%;
                            }
                        
                            .es-button {
                                mso-style-priority: 100 !important;
                                text-decoration: none !important;
                            }
                        
                            a[x-apple-data-detectors] {
                                color: inherit !important;
                                text-decoration: none !important;
                                font-size: inherit !important;
                                font-family: inherit !important;
                                font-weight: inherit !important;
                                line-height: inherit !important;
                            }
                        
                            .es-desk-hidden {
                                display: none;
                                float: left;
                                overflow: hidden;
                                width: 0;
                                max-height: 0;
                                line-height: 0;
                                mso-hide: all;
                            }
                        
                            [data-ogsb] .es-button {
                                border-width: 0 !important;
                                padding: 15px 25px 15px 25px !important;
                            }
                        
                            @media only screen and (max-width:600px),
                            screen and (max-device-width:600px) {
                        
                                p,
                                ul li,
                                ol li,
                                a {
                                line-height: 150% !important
                                }
                        
                                h1,
                                h2,
                                h3,
                                h1 a,
                                h2 a,
                                h3 a {
                                line-height: 120% !important
                                }
                        
                                h1 {
                                font-size: 36px !important;
                                text-align: center
                                }
                        
                                h2 {
                                font-size: 20px !important;
                                text-align: center
                                }
                        
                                h3 {
                                font-size: 10px !important;
                                text-align: center
                                }
                        
                                .es-header-body h1 a,
                                .es-content-body h1 a,
                                .es-footer-body h1 a {
                                font-size: 36px !important
                                }
                        
                                .es-header-body h2 a,
                                .es-content-body h2 a,
                                .es-footer-body h2 a {
                                font-size: 20px !important
                                }
                        
                                .es-header-body h3 a,
                                .es-content-body h3 a,
                                .es-footer-body h3 a {
                                font-size: 10px !important
                                }
                        
                                .es-menu td a {
                                font-size: 16px !important
                                }
                        
                                .es-header-body p,
                                .es-header-body ul li,
                                .es-header-body ol li,
                                .es-header-body a {
                                font-size: 14px !important
                                }
                        
                                .es-content-body p,
                                .es-content-body ul li,
                                .es-content-body ol li,
                                .es-content-body a {
                                font-size: 12px !important
                                }
                        
                                .es-footer-body p,
                                .es-footer-body ul li,
                                .es-footer-body ol li,
                                .es-footer-body a {
                                font-size: 10px !important
                                }
                        
                                .es-infoblock p,
                                .es-infoblock ul li,
                                .es-infoblock ol li,
                                .es-infoblock a {
                                font-size: 10px !important
                                }
                        
                                *[class="gmail-fix"] {
                                display: none !important
                                }
                        
                                .es-m-txt-c,
                                .es-m-txt-c h1,
                                .es-m-txt-c h2,
                                .es-m-txt-c h3 {
                                text-align: center !important
                                }
                        
                                .es-m-txt-r,
                                .es-m-txt-r h1,
                                .es-m-txt-r h2,
                                .es-m-txt-r h3 {
                                text-align: right !important
                                }
                        
                                .es-m-txt-l,
                                .es-m-txt-l h1,
                                .es-m-txt-l h2,
                                .es-m-txt-l h3 {
                                text-align: left !important
                                }
                        
                                .es-m-txt-r img,
                                .es-m-txt-c img,
                                .es-m-txt-l img {
                                display: inline !important
                                }
                        
                                .es-button-border {
                                display: block !important
                                }
                        
                                a.es-button,
                                button.es-button {
                                font-size: 20px !important;
                                display: block !important;
                                border-left-width: 0px !important;
                                border-right-width: 0px !important
                                }
                        
                                .es-btn-fw {
                                border-width: 10px 0px !important;
                                text-align: center !important
                                }
                        
                                .es-adaptive table,
                                .es-btn-fw,
                                .es-btn-fw-brdr,
                                .es-left,
                                .es-right {
                                width: 100% !important
                                }
                        
                                .es-content table,
                                .es-header table,
                                .es-footer table,
                                .es-content,
                                .es-footer,
                                .es-header {
                                width: 100% !important;
                                max-width: 600px !important
                                }
                        
                                .es-adapt-td {
                                display: block !important;
                                width: 100% !important
                                }
                        
                                .adapt-img {
                                width: 100% !important;
                                height: auto !important
                                }
                        
                                .es-m-p0 {
                                padding: 0px !important
                                }
                        
                                .es-m-p0r {
                                padding-right: 0px !important
                                }
                        
                                .es-m-p0l {
                                padding-left: 0px !important
                                }
                        
                                .es-m-p0t {
                                padding-top: 0px !important
                                }
                        
                                .es-m-p0b {
                                padding-bottom: 0 !important
                                }
                        
                                .es-m-p20b {
                                padding-bottom: 20px !important
                                }
                        
                                .es-mobile-hidden,
                                .es-hidden {
                                display: none !important
                                }
                        
                                tr.es-desk-hidden,
                                td.es-desk-hidden,
                                table.es-desk-hidden {
                                width: auto !important;
                                overflow: visible !important;
                                float: none !important;
                                max-height: inherit !important;
                                line-height: inherit !important
                                }
                        
                                tr.es-desk-hidden {
                                display: table-row !important
                                }
                        
                                table.es-desk-hidden {
                                display: table !important
                                }
                        
                                td.es-desk-menu-hidden {
                                display: table-cell !important
                                }
                        
                                .es-menu td {
                                width: 1% !important
                                }
                        
                                table.es-table-not-adapt,
                                .esd-block-html table {
                                width: auto !important
                                }
                        
                                table.es-social {
                                display: inline-block !important
                                }
                        
                                table.es-social td {
                                display: inline-block !important
                                }
                            }
                        </style>
                </head>
                
                <body
                    style="width:100%;font-family:lato,  helvetica, arial, sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0">
                    <div class="es-wrapper-color" style="background-color:#F4F4F4">
                    <!--[if gte mso 9]>
                            <v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
                                <v:fill type="tile" color="#f4f4f4"></v:fill>
                            </v:background>
                        <![endif]-->
                    <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0"
                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;padding:0;Margin:0;width:100%;height:100%;background-repeat:repeat;background-position:center top">
                        <tr style="border-collapse:collapse">
                        <td valign="top" style="padding:0;Margin:0">
                            <table class="es-header" cellspacing="0" cellpadding="0" align="center"
                            style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:#FFA73B;background-repeat:repeat;background-position:center top">
                            <tr style="border-collapse:collapse">
                                <td align="center" bgcolor="#000001" style="padding:0;Margin:0;background-color:#000001">
                                <table class="es-header-body" cellspacing="0" cellpadding="0" align="center"
                                    style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px">
                                    <tr style="border-collapse:collapse">
                                    <td align="left"
                                        style="Margin:0;padding-bottom:10px;padding-left:10px;padding-right:10px;padding-top:20px">
                                        <table width="100%" cellspacing="0" cellpadding="0"
                                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                        <tr style="border-collapse:collapse">
                                            <td valign="top" align="center" style="padding:0;Margin:0;width:580px">
                                            <table width="100%" cellspacing="0" cellpadding="0" role="presentation"
                                                style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                <tr style="border-collapse:collapse">
                                                <td align="center"
                                                    style="Margin:0;padding-top:5px;padding-bottom:5px;padding-left:10px;padding-right:10px;font-size:0px">
                                                    <img
                                                    src="https://rykghi.stripocdn.email/content/guids/CABINET_58cf19f9442a18cfe882708087dd543b/images/33501629124343788.png"
                                                    alt
                                                    style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"
                                                    width="170" height="48"></td>
                                                </tr>
                                            </table>
                                            </td>
                                        </tr>
                                        </table>
                                    </td>
                                    </tr>
                                </table>
                                </td>
                            </tr>
                            </table>
                            <table class="es-content" cellspacing="0" cellpadding="0" align="center"
                            style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%">
                            <tr style="border-collapse:collapse">
                                <td style="padding:0;Margin:0;background-color:#000001" bgcolor="#000001" align="center">
                                <table class="es-content-body"
                                    style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px"
                                    cellspacing="0" cellpadding="0" align="center">
                                    <tr style="border-collapse:collapse">
                                    <td align="left" style="padding:0;Margin:0">
                                        <table width="100%" cellspacing="0" cellpadding="0"
                                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                        <tr style="border-collapse:collapse">
                                            <td valign="top" align="center" style="padding:0;Margin:0;width:600px">
                                            <table
                                                style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;background-color:#ffffff;border-radius:4px"
                                                width="100%" cellspacing="0" cellpadding="0" bgcolor="#ffffff" role="presentation">
                                                <tr style="border-collapse:collapse">
                                                <td align="center"
                                                    style="Margin:0;padding-bottom:5px;padding-top:20px;padding-left:30px;padding-right:30px">
                                                    <h1
                                                    style="Margin:0;line-height:58px;mso-line-height-rule:exactly;font-family:montserrat, sans-serif;font-size:48px;font-style:normal;font-weight:normal;color:#111111">
                                                    <strong>Oh, HELLO THERE !</strong></h1>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td bgcolor="#ffffff" align="center"
                                                    style="Margin:0;padding-top:5px;padding-bottom:5px;padding-left:20px;padding-right:20px;font-size:0">
                                                    <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0"
                                                    role="presentation"
                                                    style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                    <tr style="border-collapse:collapse">
                                                        <td
                                                        style="padding:0;Margin:0;border-bottom:1px solid #ffffff;background:#FFFFFF none repeat scroll 0% 0%;height:1px;width:100%;margin:0px">
                                                        </td>
                                                    </tr>
                                                    </table>
                                                </td>
                                                </tr>
                                            </table>
                                            </td>
                                        </tr>
                                        </table>
                                    </td>
                                    </tr>
                                </table>
                                </td>
                            </tr>
                            </table>
                            <table class="es-content" cellspacing="0" cellpadding="0" align="center"
                            style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%">
                            <tr style="border-collapse:collapse">
                                <td align="center" style="padding:0;Margin:0">
                                <table class="es-content-body"
                                    style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px"
                                    cellspacing="0" cellpadding="0" align="center">
                                    <tr style="border-collapse:collapse">
                                    <td align="left" style="padding:0;Margin:0">
                                        <table width="100%" cellspacing="0" cellpadding="0"
                                        style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                        <tr style="border-collapse:collapse">
                                            <td valign="top" align="center" style="padding:0;Margin:0;width:600px">
                                            <table
                                                style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:4px;background-color:#ffffff"
                                                width="100%" cellspacing="0" cellpadding="0" bgcolor="#ffffff" role="presentation">
                                                <tr style="border-collapse:collapse">
                                                <td class="es-m-txt-l" bgcolor="#ffffff" align="left"
                                                    style="Margin:0;padding-bottom:10px;padding-top:20px;padding-left:20px;padding-right:20px">
                                                    <p
                                                    style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:montserrat, sans-serif;line-height:27px;color:#666666;font-size:18px">
                                                    Dear ;'
                                                    
                                                    
                                                    ." $name  ".
                                                    
                                                    
                                                    
                                                    
                                                    ',<br><br>We are excited to have you get started with us..! So, we need to confirm your email address so we know
                                                    that you`re reachable at this address - '
                                                    
                                                    
                                                    ." $email  ".
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    '<br><br>Your verification code is&nbsp;</p>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td class="es-m-txt-l" align="center"
                                                    style="padding:0;Margin:0;padding-top:5px;padding-left:30px;padding-right:30px">
                                                    <h1
                                                    style="Margin:0;line-height:34px;mso-line-height-rule:exactly;font-family:lato, helvetica, arial, sans-serif;font-size:28px;font-style:normal;font-weight:normal;color:#111111">
                                                    <strong><a target="_blank" href=""
                                                        style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#FFA73B;font-size:32px;font-family:montserrat, sans-serif;letter-spacing:4px">'
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        . " $code".
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        '</a></strong>
                                                    </h1>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td class="es-m-txt-l" align="left"
                                                    style="padding:0;Margin:0;padding-top:20px;padding-left:30px;padding-right:30px">
                                                    <p
                                                    style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:montserrat, sans-serif;line-height:27px;color:#666666;font-size:18px">
                                                    If you have any questions, just reply to this email—we`re always happy to service you up.
                                                    </p>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td class="es-m-txt-l" align="left"
                                                    style="padding:0;Margin:0;padding-top:20px;padding-left:30px;padding-right:30px">
                                                    <p
                                                    style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:montserrat, sans-serif;line-height:27px;color:#666666;font-size:18px">
                                                    Regards,</p>
                                                    <p
                                                    style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:montserrat, sans-serif;line-height:27px;color:#666666;font-size:18px">
                                                    The C-19 Team</p>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td align="center" style="padding:10px;Margin:0;font-size:0">
                                                    <table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0"
                                                    role="presentation"
                                                    style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                    <tr style="border-collapse:collapse">
                                                        <td
                                                        style="padding:0;Margin:0;border-bottom:1px solid #cccccc;background:none;height:1px;width:100%;margin:0px">
                                                        </td>
                                                    </tr>
                                                    </table>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td align="center" style="padding:0;Margin:0;font-size:0">
                                                    <table cellpadding="0" cellspacing="0" class="es-table-not-adapt es-social"
                                                    role="presentation"
                                                    style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                                                    <tr style="border-collapse:collapse">
                                                        <td align="center" valign="top" style="padding:0;Margin:0;padding-right:10px"><img
                                                            title="Facebook"
                                                            src="https://rykghi.stripocdn.email/content/assets/img/social-icons/logo-black/facebook-logo-black.png"
                                                            alt="Fb" width="32" height="32"
                                                            style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic">
                                                        </td>
                                                        <td align="center" valign="top" style="padding:0;Margin:0;padding-right:10px"><img
                                                            title="Twitter"
                                                            src="https://rykghi.stripocdn.email/content/assets/img/social-icons/logo-black/twitter-logo-black.png"
                                                            alt="Tw" width="32" height="32"
                                                            style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic">
                                                        </td>
                                                        <td align="center" valign="top" style="padding:0;Margin:0"><img title="Instagram"
                                                            src="https://rykghi.stripocdn.email/content/assets/img/social-icons/logo-black/instagram-logo-black.png"
                                                            alt="Inst" width="32" height="32"
                                                            style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic">
                                                        </td>
                                                    </tr>
                                                    </table>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td align="center" style="padding:0;Margin:0;padding-top:15px">
                                                    <h3
                                                    style="Margin:0;line-height:17px;mso-line-height-rule:exactly;font-family:"open sans", helvetica, arial, sans-serif;font-size:10px;font-style:normal;font-weight:normal;color:#666666; padding-left: 15px; padding-right: 15px;">
                                                    You received this email because you just signed up for a new account.&nbsp;Make sure
                                                    our messages gets to your inbox.</h3>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td align="center" style="padding:0;Margin:0;padding-top:5px">
                                                    <p
                                                    style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:lato, helvetica, arial, sans-serif;line-height:15px;color:#666666;font-size:10px">
                                                    &nbsp;<strong><a target="_blank" class="unsubscribe" href=""
                                                        style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#FFA73B;font-size:10px">Privacy
                                                        Policy</a> | <a target="_blank" class="unsubscribe" href=""
                                                        style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#FFA73B;font-size:10px">Terms
                                                        &amp; Conditions</a></strong>.</p>
                                                </td>
                                                </tr>
                                                <tr style="border-collapse:collapse">
                                                <td align="center" style="padding:0;Margin:0;padding-top:25px">
                                                    <p
                                                    style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:helvetica,  arial, verdana, sans-serif;line-height:18px;color:#666666;font-size:12px">
                                                    ©2021 C19-Covid-19. All Rights Reserved.</p>
                                                </td>
                                                </tr>
                                            </table>
                                            </td>
                                        </tr>
                                        </table>
                                    </td>
                                    </tr>
                                </table>
                                </td>
                            </tr>
                            </table>
                        </td>
                        </tr>
                    </table>
                    </div>
                </body>
                
                </html>';

                
                    $subject = "Email verification for new Signup with C-19";
                    $mail->addAddress($email);

                    // Content
                    $mail->isHTML(true);                                  // Set email format to HTML
                    $mail->Subject = $subject;
                    $mail->Body    = $html;
                

                    if($mail->send()){
                        $info = "We've sent a verification code to your email - $email  ";
                        $_SESSION['info'] = $info;
                        $_SESSION['isLogin'] = false;
                        header('location: user-otp.php');
                        exit();
                    }else{
                        $errors['otp-error'] = "Failed while sending code!";
                    }
                }else{
                    $errors['db-error'] = "Failed while inserting data into database!";
                }
            }
        }
    }else{
        header('location: index.php');
    }


?>


<!doctype html>
<html lang="en">

<head>
    <title>Covid - SignUp</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/favicon2.ico" type="image/x-icon">

    <!-- <meta name="theme-color" content="#6f42c1"> -->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

    <!-- Bootstrap CDN links -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- Custom Style sheet -->
    <link rel="stylesheet" href="css/style.css">

    <!-- page specifi style sheet -->
    <style>
        .container .form {
            background: #fff;
            border-radius: 5px;
            margin-left: -20px;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.075), 0 6px 20px 0 rgba(0, 0, 0, 0.075);
        }

        .container .form form .form-control {
            height: 40px;
            font-size: 15px;
        }

        .container .form form .forget-pass {
            margin: -15px 0 15px 0;
        }

        .container .form form .forget-pass a {
            font-size: 15px;
        }

        .container .form form .button {
            background: #6665ee;
            color: #fff;
            font-size: 17px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .container .form form .button:hover {
            background: #5757d1;
        }

        .container .form form .link {
            padding: 5px 0;
        }

        .container .form form .link a {
            color: #6665ee;
        }

        .container .login-form form p {
            font-size: 14px;
        }

        .container .row .alert {
            font-size: 14px;
        }
    </style>
</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


    <div id="overlayer"></div>
    <div class="loader row flex-column align-items-center align-content-center">
        <div class="spinner-border text-primary" role="status"> </div>
        <h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
        <p class="mt-0">Loading...</p>
    </div>

    <div class="site-wrap">

        <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>


        <!-- header -->
        <?php require "header.php";?>


        <div class="site-section">
            <div class="container  bg-2 ">
                <div class="myrow ml-0 pl-0 mt-4">
                    <div class=" col-lg-4 col-md-6 login-section-wrapper pl-3 pr-3 form login-form">
                        <form action="signup.php" method="POST">
                            <div>
                                <p class="span-red ">Hello there! <span> &nbsp; Sign Up</span></p>
                            </div>
                            <?php
                                    if(count($errors) == 1){
                                        ?>
                            <div class="alert alert-danger text-center">
                                <?php
                                            foreach($errors as $showerror){
                                                echo $showerror;
                                            }
                                            ?>
                            </div>
                            <?php
                                    }elseif(count($errors) > 1){
                                        ?>
                            <div class="alert alert-danger">
                                <?php
                                            foreach($errors as $showerror){
                                                ?>
                                <li><?php echo $showerror; ?></li>
                                <?php
                                            }
                                            ?>
                            </div>
                            <?php
                                    }
                                ?>


                            <div class="form-row">
                                <div class="col form-group ">
                                    <label class="text-black">Full name</label>
                                    <input class="form-control" type="text" name="name" placeholder="ex. Harry"
                                        value="<?php echo $name ?>" required>
                                    <div class="invalid-feedback">
                                        Oh no! Email is invalid.
                                    </div>
                                </div>
                            </div> <!-- form-row end.// -->

                            <div class="form-group">
                                <label class="text-black">Email</label>
                                <input class="form-control" type="email" name="email" placeholder="ex. name@gmail.com"
                                    value="<?php echo $email ?>" required>
                                <small class="form-text text-muted red">We'll never share your email with anyone
                                    else.</small>
                            </div>

                            <div class="form-group ">
                                <label class="text-black">Create password</label>
                                <input class="form-control" type="password" name="password"
                                    placeholder="ex. Abcd#Xyz@1234" required>

                            </div>
                            <div class="form-group ">
                                <label class="text-black">Confirm password</label>
                                <input class="form-control" type="password" name="cpassword"
                                    placeholder="eg. repeat your password " required>

                            </div>


                            <div class="form-group mt-3">
                                <button type="submit" class="btn btn-primary btn-block font-weight-bold" name="signup"
                                    value="Signup"> Sign Up </button>
                            </div> <!-- form-group// -->
                            <p class="text-muted">By clicking the 'Sign Up' button, you confirm that you accept
                                our Terms of use and Privacy Policy.</p>
                            <hr>
                            <p class="text-center">Have an account? <a class="red" href="login.php">Login</a> here</p>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <!-- footer -->
    <?php require "footer.php";?>

    </div> <!-- .site-wrap -->

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>


    <script src="js/main.js"></script>


</body>

</html>