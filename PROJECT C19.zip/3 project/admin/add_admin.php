<?php 
    require"../connection.php";
    session_start();

	$aid = $_SESSION['admin_id'];
    if($aid == false){
        header('Location: admin_login.php');
    }

    
    $email = "";
    $name = "";
    $errors = array();

    
        if(isset($_POST['submit'])){
            
            $name = mysqli_real_escape_string($con, $_POST['name']);
            $email = mysqli_real_escape_string($con, $_POST['email']);
            $password = mysqli_real_escape_string($con, $_POST['password']);

            $unq_id = "admin".rand(11111,9999);


            if(trim(strlen($password)) < 8){
                $errors['password_char'] = "Password must be 8 characters long, so it should be strong";
            }

            if(count($errors) === 0){
                $encpass = password_hash($password, PASSWORD_BCRYPT);

                $insert_data = "INSERT INTO admintable (admin_name,admin_email, admin_unq_id, admin_password)
                                values('$name','$email','$unq_id', '$encpass')";
                $data_check = mysqli_query($con, $insert_data);

                if($data_check){
                    echo "<script>alert('ADMIN add successfully');</script>";
                    echo "<script type='text/javascript'> document.location ='view_all_admins.php'; </script>";
                }else{
                    $errors['db-error'] = "Failed while inserting data into database!";
                }
            }
        }
    

?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
	<title>Admin Dashboard &mdash; Covid-19</title>

	<!-- General CSS Files -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
		integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
		integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

	<!-- CSS Libraries -->
	<!-- <link rel="stylesheet" href="../node_modules/jqvmap/dist/jqvmap.min.css"> -->
	<link rel="stylesheet" href="../node_modules/summernote/dist/summernote-bs4.css">
	<link rel="stylesheet" href="../node_modules/owl.carousel/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="../node_modules/owl.carousel/dist/assets/owl.theme.default.min.css">

	<!-- Template CSS -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/components.css">
</head>

<body>
	<div id="app">
		<div class="main-wrapper">
			<div class="navbar-bg"></div>
			<nav class="navbar navbar-expand-lg main-navbar bg-primary">
				<div class="navbar-nav mr-3"><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i
							class="fas fa-bars"></i></a></div>
				<ul class="navbar-nav navbar-right ">
					<div class="text-white " style="font-size: large;"> C<span class=" fas fa-virus " "></span>vid-19. </div>
                </ul>
            </nav>
    
			<div class=" main-sidebar">
				<aside id="sidebar-wrapper">
					<div class="sidebar-brand">
						<a href="admin_index.php">C<span class=" fas fa-virus " "></span>vid-19.</a>
					</div>

					<div class=" sidebar-brand sidebar-brand-sm">
								<a href="admin_index.php"><i class=" fas fa-virus "
										style="font-size: 26px;"></i></a>
					</div>

					<ul class="sidebar-menu">
						<li></li>
						<li></li>
						
						<li class="menu-header">Admin</li>
						<li ><a class="nav-link" href="admin_index.php"><i class="fas fa-home"></i>
								<span>HOME</span></a>
						</li>
						<li class="active"><a class="nav-link" href="view_all_admins.php"><i class="fas fa-user-shield"></i>
								<span>ADMIN view</span></a>
						</li>

						<li class="menu-header">Dashboard</li>
						<li ><a class="nav-link" href="admin_vaccination.php"><i class="fas fa-syringe"></i>
								<span>Vaccination</span></a>
						</li>

						<li><a class="nav-link" href="admin_user_view.php"><i class="fas fa-user"></i>
								<span>Users</span></a>
						</li>

						<li class="menu-header">Ecommerce</li>
						<li><a class="nav-link" href="admin_products.php"><i class="fas fa-shopping-cart"></i>
								<span>Products</span></a>
						</li>

						<li><a class="nav-link" href="admin_shipping.php"><i class="fas fa-shipping-fast"></i>
								<span>Shipping</span></a>
						</li>

						<li><a class="nav-link" href="admin_orders.php"><i class="fas fa-file-invoice"></i>
								<span>Orders</span></a>
						</li>

						
					</ul>

					<div class="mt-4 mb-4 p-3 hide-sidebar-mini">
						<a href="admin_logout.php" class="btn btn-primary btn-lg btn-block btn-icon-split">
							<i class="fas fa-sign-out-alt"></i></i> Logout
						</a>
					</div>
				</aside>
			</div>




					<!-- Main Content -->
					<div class="main-content">
						<section class="section">
							<div class="section-header">
								<h1>ADD ADMIN</h1>
								<div class="section-header-breadcrumb">
									<div class="breadcrumb-item active"><a href="admin_index.php">Dashboard </a></div>
									<div class="breadcrumb-item active"><a href="view_all_admins.php">ADMIN view </a></div>
									<div class="breadcrumb-item ">Add Admin</div>
								</div>    
							</div>

							
                            
                            <div class="section-body">


                                <div class="row mt-sm-4">

                                    <div class="col-12 col-md-12 col-lg-7">
                                        <div class="card">
                                            <form method="post"  enctype="">
                                                <div class="card-header">
                                                    <h4>Fill the details </h4>
                                                </div>

                                                <?php
                                    if(count($errors) == 1){
                                        ?>
                                        <div class="alert alert-danger text-center">
                                            <?php
                                            foreach($errors as $showerror){
                                                echo $showerror;
                                            }
                                            ?>
                                        </div>
                                        <?php
                                    }elseif(count($errors) > 1){
                                        ?>
                                        <div class="alert alert-danger">
                                            <?php
                                            foreach($errors as $showerror){
                                                ?>
                                                <li><?php echo $showerror; ?></li>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        <?php
                                    }
                                ?>

                                                
                                                <div class="card-body">

                                                    <div class="row">
                                                        <div class="form-group col-md-6 col-12">
                                                            <label>Admin Name</label>
                                                            <input type="text" name="name" class="form-control" required   ">
                                                        </div>

                                                        <div class="form-group col-md-6 col-12">
                                                            <label>Email</label>
                                                            <input type="text" name="email" class="form-control" required   ">
                                                        </div>

                                                        <div class="form-group col-md-6 col-12">
                                                            <label>Password</label>
                                                            <input type="password" name="password" class="form-control" required  " >
                                                        </div>


                                                        <div class="form-group col-md-12 col-12">
                                                            
                                                            <p>A Unique ID would be generated in after submitting, which can be view in the ADMIN view page.</p>
                                                        </div>
													
                                                </div>  <!--card body -->
                                                <div class="card-footer text-right">
                                                    <button name="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>



                            </div>
                            <!---- section body --->

					</div>  <!---main contect-->

					</section>
		</div>

	</div>


	<!-- footer -->
	<?php require "footer.php";?>
	</div>
	</div>

	<!-- General JS Scripts -->
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"
		integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
		integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
	</script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
		integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
	<script src="js/stisla.js"></script>

	<!-- JS Libraies -->
	<script src="../node_modules/jquery-sparkline/jquery.sparkline.min.js"></script>
	<script src="../node_modules/chart.js/dist/Chart.min.js"></script>
	<script src="../node_modules/owl.carousel/dist/owl.carousel.min.js"></script>
	<script src="../node_modules/summernote/dist/summernote-bs4.js"></script>
	<script src="../node_modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

	<!-- Template JS File -->
	<script src="js/scripts.js"></script>
	<script src="js/custom.js"></script>

	<!-- Page Specific JS File -->
	<script src="js/page/admin_index.js"></script>
</body>

</html>
