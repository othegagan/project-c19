<?php 
$aid = $_SESSION['admin_id'];
if($aid == false){
    header('Location: admin_login.php');
}

?>

<footer class="main-footer pr-xs-1 pl-xs-1">
    <div class=" col-md-6 ">
        <p>&copy;<script>
            document.write(new Date().getFullYear());
        </script>
        <span class="text-primary">C19-Covid-19.</span> All Rights Reserved.</p>
    </div>
</footer>