<?php 
    require"../connection.php";
    session_start();

	$aid = $_SESSION['admin_id'];
    if($aid == false){
        header('Location: admin_login.php');
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
	<title>Admin Dashboard &mdash; Covid-19</title>

	<!-- General CSS Files -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
		integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
		integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

	<!-- CSS Libraries -->
	<!-- <link rel="stylesheet" href="../node_modules/jqvmap/dist/jqvmap.min.css"> -->
	<link rel="stylesheet" href="../node_modules/summernote/dist/summernote-bs4.css">
	<link rel="stylesheet" href="../node_modules/owl.carousel/dist/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="../node_modules/owl.carousel/dist/assets/owl.theme.default.min.css">

	<!-- Template CSS -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/components.css">
</head>

<body>
	<div id="app">
		<div class="main-wrapper">
			<div class="navbar-bg"></div>
			<nav class="navbar navbar-expand-lg main-navbar bg-primary">
				<div class="navbar-nav mr-3"><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i
							class="fas fa-bars"></i></a></div>
				<ul class="navbar-nav navbar-right ">
					<div class="text-white " style="font-size: large;"> C<span class=" fas fa-virus " "></span>vid-19. </div>
                </ul>
            </nav>
    
			<div class=" main-sidebar">
				<aside id="sidebar-wrapper">
					<div class="sidebar-brand">
						<a href="admin_index.php">C<span class=" fas fa-virus " "></span>vid-19.</a>
					</div>

					<div class=" sidebar-brand sidebar-brand-sm">
								<a href="admin_index.php"><i class=" fas fa-virus "
										style="font-size: 26px;"></i></a>
					</div>

					<ul class="sidebar-menu">
						<li></li>
						<li></li>
						
						<li class="menu-header">Admin</li>
						<li ><a class="nav-link" href="admin_index.php"><i class="fas fa-home"></i>
								<span>HOME</span></a>
						</li>
						<li ><a class="nav-link" href="view_all_admins.php"><i class="fas fa-user-shield"></i>
								<span>ADMIN view</span></a>
						</li>

						<li class="menu-header">Dashboard</li>
						<li ><a class="nav-link" href="admin_vaccination.php"><i class="fas fa-syringe"></i>
								<span>Vaccination</span></a>
						</li>

						<li><a class="nav-link" href="admin_user_view.php"><i class="fas fa-user"></i>
								<span>Users</span></a>
						</li>

						<li class="menu-header">Ecommerce</li>
						<li><a class="nav-link" href="admin_products.php"><i class="fas fa-shopping-cart"></i>
								<span>Products</span></a>
						</li>

						<li><a class="nav-link" href="admin_shipping.php"><i class="fas fa-shipping-fast"></i>
								<span>Shipping</span></a>
						</li>

						<li class="active"><a class="nav-link" href="admin_orders.php"><i class="fas fa-file-invoice"></i>
								<span>Orders</span></a>
						</li>

						
					</ul>

					<div class="mt-4 mb-4 p-3 hide-sidebar-mini">
						<a href="admin_logout.php" class="btn btn-primary btn-lg btn-block btn-icon-split">
							<i class="fas fa-sign-out-alt"></i></i> Logout
						</a>
					</div>
				</aside>
			</div>




					<!-- Main Content -->
					<div class="main-content">
						<section class="section">
							<div class="section-header">
								<h1>Orders</h1>
								<div class="section-header-breadcrumb">
									<div class="breadcrumb-item active"><a href="admin_index.php">Dashboard </a></div>
									<div class="breadcrumb-item ">Orders</div>
								</div>
							</div>

							<div class="section-body">
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Order ID</th>
                                                        <th>Name</th>
                                                        <th>Phone Number</th>
                                                        <th>Address</th>
                                                        <th>Products</th>
                                                        <th>Ordered Date</th>
                                                        <th>Ordered Status</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <tr>
                                                        <?php
                                                            $result=mysqli_query($con,"select * from orders");
                                                            $row=mysqli_num_rows($result);
															$count=1;
                                                            if($row>0){
                                                                    while ($row=mysqli_fetch_array($result)) {
                                                                        ?>
                                                                            <!--Fetch the Records -->
                                                                            <tr>
                                                                                <td><?php echo $count;?></td>
                                                                                <td><?php  echo $row['order_id'];?></td>
                                                                                <td><?php  echo $row['name'];?></td>
                                                                                <td><?php  echo $row['phone_number'];?></td>
                                                                                <td> <?php  echo $row['address'];?></td>
                                                                                <td> <?php  echo $row['product_list'];?></td>
                                                                                <td> <?php  echo $row['ordered_date'];?></td>
                                                                                <td>
                                                                                    <?php 
                                                                                        $order_status = $row['order_status'];
                                                                                        if($order_status == "not done"){
                                                                                            ?><div class="badge badge-pill badge-danger mb-1 ">Not done</div><?php
                                                                                        }else{
                                                                                            ?><div class="badge  badge-success mb-1 ">done</div><?php
                                                                                        }
                                                                                    ?> 
                                                                                </td>

                                                                                <td width="15%">
                                                                                    <a	href="admin_order_view.php?view_id=<?php echo ($row['order_id']);?>"
																						class="btn btn-warning btn-action mr-1"
                                                                                        data-toggle="tooltip" title=""
                                                                                        data-original-title="View">
                                                                                        <i class="fas fa-eye"></i>
                                                                                    </a>
																						
																					<?php 
																					
																						if ($row['order_status'] == 'not done') {
																							?>
																							<a 	href="admin_order_edit.php?edit_id=<?php echo ($row['order_id']);?>"
																								class="btn btn-primary btn-action mr-1"
																								data-toggle="tooltip" title=""
																								data-original-title="Edit">
																								<i class="fas fa-pencil-alt"></i>
																							</a>
																							<?php
																						}
																					?>
                                                                                    


																					<!-- Code for deletion -->
																					<?php 
																						if(isset($_GET['delid']))
																						{
																							$rid=intval($_GET['delid']);
																							$sql=mysqli_query($con,"delete from orders where order_id=$rid");
																							echo "<script>alert('Data deleted');</script>"; 
																							echo "<script>window.location.href = 'admin_orders.php'</script>";     
																						} 
																					?>

                                                                                    <a 	href="admin_orders.php?delid=<?php echo ($row['order_id']);?>"
																						onclick="return confirm('Do you really want to Delete ?');"
																						class="btn btn-danger"
                                                                                        data-toggle="tooltip" title=""
                                                                                        data-original-title="Delete">
                                                                                        <i class="fas fa-trash"></i>
																					</a>
                                                                                </td>

                                                                                
                                                                
                                                                            </tr> 
                                                                        <?php 
																		$count=$count+1;
                                                                }
                                                            } else {
                                                                ?>
                                                                    <tr>
                                                                        <th style="text-align:center; color:red;" colspan="6">No Record Found</th>
                                                                    </tr>
                                                                <?php 
                                                            } 
                                                        ?>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

								<!-- </div> -->
								<!---- row --->

							</div>
							<!---- section body --->


					</div>  <!---main contect-->
					</section>
		</div>

	</div>


	<!-- footer -->
	<?php require "footer.php";?>
	</div>
	</div>

	<!-- General JS Scripts -->
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"
		integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
		integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
	</script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
		integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
	<script src="js/stisla.js"></script>

	<!-- JS Libraies -->
	<script src="../node_modules/jquery-sparkline/jquery.sparkline.min.js"></script>
	<script src="../node_modules/chart.js/dist/Chart.min.js"></script>
	<script src="../node_modules/owl.carousel/dist/owl.carousel.min.js"></script>
	<script src="../node_modules/summernote/dist/summernote-bs4.js"></script>
	<script src="../node_modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

	<!-- Template JS File -->
	<script src="js/scripts.js"></script>
	<script src="js/custom.js"></script>

	<!-- Page Specific JS File -->
	<script src="js/page/admin_index.js"></script>
</body>

</html>
