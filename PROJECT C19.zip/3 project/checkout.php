<?php 

	require "connection.php";
	session_start();

	include('libs/phpqrcode/qrlib.php'); 
	// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\Exception;
		
		// Load Composer's autoloader
		require 'vendor/autoload.php';
		
		$mail = new PHPMailer(true);

		
			//Server settings
			$mail->SMTPDebug = 0;                                       // Enable verbose debug output
			$mail->isSMTP();                                            // Set mailer to use SMTP
			$mail->Host       = 'smtp.gmail.com;';  // Specify main and backup SMTP servers
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = 'projectcovid2@gmail.com';                     // SMTP username
			$mail->Password   = 'Covid19#';                               // SMTP password
			$mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to
		
			//Recipients
			$mail->setFrom('projectcovid2@gmail.com', 'PROJECT C-19');
			
			// $file_name = $_FILES["file"]["name"];
			// move_uploaded_file($_FILES["file"]["tmp_name"], $file_name);
			// $mail->addAttachment($file_name);

	function IND_money_format($number){    	
		$decimal = (string)($number - floor($number));
		$money = floor($number);
		$length = strlen($money);
		$delimiter = '';
		$money = strrev($money);

		for($i=0;$i<$length;$i++){
			if(( $i==3 || ($i>3 && ($i-1)%2==0) )&& $i!=$length){
				$delimiter .=',';
			}
			$delimiter .=$money[$i];
		}

		$result = strrev($delimiter);
		$decimal = preg_replace("/0\./i", ".", $decimal);
		$decimal = substr($decimal, 0, 3);

		if( $decimal != '0'){
			$result = $result.$decimal;
		}

		return $result;
	}
		
	$email = $_SESSION['email'];
	if($email == false){
		header('Location: login.php');
	}
	
	if(isset($_POST['confirm'])){
		$first_name = mysqli_real_escape_string($con, $_POST['first_name']);
		$last_name = mysqli_real_escape_string($con, $_POST['last_name']);
		$phone_number = mysqli_real_escape_string($con, $_POST['phone_number']);
		$email = mysqli_real_escape_string($con, $_POST['email']);
		$building_number = mysqli_real_escape_string($con, $_POST['building_number']);
		$street = mysqli_real_escape_string($con, $_POST['street']);
		$area = mysqli_real_escape_string($con, $_POST['area']);
		$city = mysqli_real_escape_string($con, $_POST['city']);
		$code = mysqli_real_escape_string($con, $_POST['code']);
		$card_number = mysqli_real_escape_string($con, $_POST['card_number']);

		$order_reference = rand(1111119,9999999);
		$full_name = $first_name ."  ". $last_name;
		$address = $building_number." ".$street." ". $area . " " . $city . " " . $code;

		$list = implode(',',$_SESSION['cart_items']);

		$total = $_SESSION['grand_total'];
		$id = $_SESSION['id'];


		$insert_query = "INSERT INTO orders(order_id, name, phone_number, email, address, card_number, product_list, total_amount) VALUES ('$order_reference','$full_name','$phone_number','$email','$address','$card_number','$list','$total')";

		$query = mysqli_query($con,$insert_query);

		if ($query) {
			$get_data = mysqli_query($con,"SELECT * FROM orders WHERE order_id = $order_reference");
			$fetch_data = mysqli_fetch_assoc($get_data);
			$ordered_date = $fetch_data['ordered_date'];

			$delete_query  = "DELETE FROM `user_items` WHERE user_id = $id";
			$delete = mysqli_query($con,$delete_query);

			if ($delete_query) {

				$temp_total =$_SESSION['temp_total'];
				$ship = $_SESSION['ship_charge'];
				$cart_gst = $_SESSION['cart_gst'];
				$cart_discount = $_SESSION['cart_discount'];
				$g_total = $_SESSION['grand_total'];

				$qrcode = "Order ID : $order_reference | Name: $full_name | Ordered Date : $ordered_date | Products : $list | Total: $g_total  ";
				
				QRcode::png("$qrcode", 'admin/qrcodes/'."$order_reference".'.png', QR_ECLEVEL_L, 5);

				$html = '<!DOCTYPE html
				PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
			<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office"
				style="font-family:arial,  helvetica, sans-serif">
			
			<head>
				<meta charset="UTF-8">
				<meta content="width=device-width, initial-scale=1" name="viewport">
				<meta name="x-apple-disable-message-reformatting">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<meta content="telephone=no" name="format-detection">
				<title>New Template</title>
				<!--[if (mso 16)]>
				<style type="text/css">
				a {text-decoration: none;}
				</style>
				<![endif]-->
				<!--[if gte mso 9]><style>sup { font-size: 100% !important; }</style><![endif]-->
				<!--[if gte mso 9]>
			<xml>
				<o:OfficeDocumentSettings>
				<o:AllowPNG></o:AllowPNG>
				<o:PixelsPerInch>96</o:PixelsPerInch>
				</o:OfficeDocumentSettings>
			</xml>
			<![endif]-->
				<style type="text/css">
				#outlook a {
					padding: 0;
				}
			
				.es-button {
					mso-style-priority: 100 !important;
					text-decoration: none !important;
				}
			
				a[x-apple-data-detectors] {
					color: inherit !important;
					text-decoration: none !important;
					font-size: inherit !important;
					font-family: inherit !important;
					font-weight: inherit !important;
					line-height: inherit !important;
				}
			
				.es-desk-hidden {
					display: none;
					float: left;
					overflow: hidden;
					width: 0;
					max-height: 0;
					line-height: 0;
					mso-hide: all;
				}
			
				[data-ogsb] .es-button {
					border-width: 0 !important;
					padding: 10px 30px 10px 30px !important;
				}
			
				@media only screen and (max-width:600px),
				screen and (max-device-width:600px) {
			
					p,
					ul li,
					ol li,
					a {
					line-height: 150% !important
					}
			
					h1,
					h2,
					h3,
					h1 a,
					h2 a,
					h3 a {
					line-height: 120% !important
					}
			
					h1 {
					font-size: 36px !important;
					text-align: center
					}
			
					h2 {
					font-size: 26px !important;
					text-align: center
					}
			
					h3 {
					font-size: 20px !important;
					text-align: center
					}
			
					.es-header-body h1 a,
					.es-content-body h1 a,
					.es-footer-body h1 a {
					font-size: 36px !important
					}
			
					.es-header-body h2 a,
					.es-content-body h2 a,
					.es-footer-body h2 a {
					font-size: 26px !important
					}
			
					.es-header-body h3 a,
					.es-content-body h3 a,
					.es-footer-body h3 a {
					font-size: 20px !important
					}
			
					.es-menu td a {
					font-size: 14px !important
					}
			
					.es-header-body p,
					.es-header-body ul li,
					.es-header-body ol li,
					.es-header-body a {
					font-size: 14px !important
					}
			
					.es-content-body p,
					.es-content-body ul li,
					.es-content-body ol li,
					.es-content-body a {
					font-size: 14px !important
					}
			
					.es-footer-body p,
					.es-footer-body ul li,
					.es-footer-body ol li,
					.es-footer-body a {
					font-size: 14px !important
					}
			
					.es-infoblock p,
					.es-infoblock ul li,
					.es-infoblock ol li,
					.es-infoblock a {
					font-size: 12px !important
					}
			
					*[class="gmail-fix"] {
					display: none !important
					}
			
					.es-m-txt-c,
					.es-m-txt-c h1,
					.es-m-txt-c h2,
					.es-m-txt-c h3 {
					text-align: center !important
					}
			
					.es-m-txt-r,
					.es-m-txt-r h1,
					.es-m-txt-r h2,
					.es-m-txt-r h3 {
					text-align: right !important
					}
			
					.es-m-txt-l,
					.es-m-txt-l h1,
					.es-m-txt-l h2,
					.es-m-txt-l h3 {
					text-align: left !important
					}
			
					.es-m-txt-r img,
					.es-m-txt-c img,
					.es-m-txt-l img {
					display: inline !important
					}
			
					.es-button-border {
					display: inline-block !important
					}
			
					a.es-button,
					button.es-button {
					font-size: 20px !important;
					display: inline-block !important
					}
			
					.es-adaptive table,
					.es-left,
					.es-right {
					width: 100% !important
					}
			
					.es-content table,
					.es-header table,
					.es-footer table,
					.es-content,
					.es-footer,
					.es-header {
					width: 100% !important;
					max-width: 600px !important
					}
			
					.es-adapt-td {
					display: block !important;
					width: 100% !important
					}
			
					.adapt-img {
					width: 100% !important;
					height: auto !important
					}
			
					.es-m-p0 {
					padding: 0 !important
					}
			
					.es-m-p0r {
					padding-right: 0 !important
					}
			
					.es-m-p0l {
					padding-left: 0 !important
					}
			
					.es-m-p0t {
					padding-top: 0 !important
					}
			
					.es-m-p0b {
					padding-bottom: 0 !important
					}
			
					.es-m-p20b {
					padding-bottom: 20px !important
					}
			
					.es-mobile-hidden,
					.es-hidden {
					display: none !important
					}
			
					tr.es-desk-hidden,
					td.es-desk-hidden,
					table.es-desk-hidden {
					width: auto !important;
					overflow: visible !important;
					float: none !important;
					max-height: inherit !important;
					line-height: inherit !important
					}
			
					tr.es-desk-hidden {
					display: table-row !important
					}
			
					table.es-desk-hidden {
					display: table !important
					}
			
					td.es-desk-menu-hidden {
					display: table-cell !important
					}
			
					.es-menu td {
					width: 1% !important
					}
			
					table.es-table-not-adapt,
					.esd-block-html table {
					width: auto !important
					}
			
					table.es-social {
					display: inline-block !important
					}
			
					table.es-social td {
					display: inline-block !important
					}
			
					.es-m-p5 {
					padding: 5px !important
					}
			
					.es-m-p5t {
					padding-top: 5px !important
					}
			
					.es-m-p5b {
					padding-bottom: 5px !important
					}
			
					.es-m-p5r {
					padding-right: 5px !important
					}
			
					.es-m-p5l {
					padding-left: 5px !important
					}
			
					.es-m-p10 {
					padding: 10px !important
					}
			
					.es-m-p10t {
					padding-top: 10px !important
					}
			
					.es-m-p10b {
					padding-bottom: 10px !important
					}
			
					.es-m-p10r {
					padding-right: 10px !important
					}
			
					.es-m-p10l {
					padding-left: 10px !important
					}
			
					.es-m-p15 {
					padding: 15px !important
					}
			
					.es-m-p15t {
					padding-top: 15px !important
					}
			
					.es-m-p15b {
					padding-bottom: 15px !important
					}
			
					.es-m-p15r {
					padding-right: 15px !important
					}
			
					.es-m-p15l {
					padding-left: 15px !important
					}
			
					.es-m-p20 {
					padding: 20px !important
					}
			
					.es-m-p20t {
					padding-top: 20px !important
					}
			
					.es-m-p20r {
					padding-right: 20px !important
					}
			
					.es-m-p20l {
					padding-left: 20px !important
					}
			
					.es-m-p25 {
					padding: 25px !important
					}
			
					.es-m-p25t {
					padding-top: 25px !important
					}
			
					.es-m-p25b {
					padding-bottom: 25px !important
					}
			
					.es-m-p25r {
					padding-right: 25px !important
					}
			
					.es-m-p25l {
					padding-left: 25px !important
					}
			
					.es-m-p30 {
					padding: 30px !important
					}
			
					.es-m-p30t {
					padding-top: 30px !important
					}
			
					.es-m-p30b {
					padding-bottom: 30px !important
					}
			
					.es-m-p30r {
					padding-right: 30px !important
					}
			
					.es-m-p30l {
					padding-left: 30px !important
					}
			
					.es-m-p35 {
					padding: 35px !important
					}
			
					.es-m-p35t {
					padding-top: 35px !important
					}
			
					.es-m-p35b {
					padding-bottom: 35px !important
					}
			
					.es-m-p35r {
					padding-right: 35px !important
					}
			
					.es-m-p35l {
					padding-left: 35px !important
					}
			
					.es-m-p40 {
					padding: 40px !important
					}
			
					.es-m-p40t {
					padding-top: 40px !important
					}
			
					.es-m-p40b {
					padding-bottom: 40px !important
					}
			
					.es-m-p40r {
					padding-right: 40px !important
					}
			
					.es-m-p40l {
					padding-left: 40px !important
					}
				}
				</style>
			</head>
			
			<body
				style="width:100%;font-family:arial,  helvetica, sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0">
				<div class="es-wrapper-color" style="background-color:#FAFAFA">
				<!--[if gte mso 9]>
					<v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
					<v:fill type="tile" color="#fafafa"></v:fill>
					</v:background>
				<![endif]-->
				<table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0"
					style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;padding:0;Margin:0;width:100%;height:100%;background-repeat:repeat;background-position:center top;background-color:#FAFAFA">
					<tr>
					<td valign="top" style="padding:0;Margin:0">
						<table cellpadding="0" cellspacing="0" class="es-header" align="center"
						style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top">
						<tr>
							<td align="center" style="padding:0;Margin:0;background-color:#010000" bgcolor="#010000">
							<table bgcolor="#0b0b0b" class="es-header-body" align="center" cellpadding="0" cellspacing="0"
								style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#0b0b0b;width:600px">
								<tr>
								<td align="left" style="padding:20px;Margin:0">
									<table cellpadding="0" cellspacing="0" width="100%"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
									<tr>
										<td class="es-m-p0r" valign="top" align="center" style="padding:0;Margin:0;width:560px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="center" style="padding:0;Margin:0;padding-bottom:10px;font-size:0px"><img
												src="https://pydxgs.stripocdn.email/content/guids/CABINET_592d4c028092f2d2c5a81ce07260e735/images/12051629209563100.png"
												alt="Logo"
												style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;font-size:12px"
												width="200" title="Logo" height="56"></td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
								</td>
								</tr>
							</table>
							</td>
						</tr>
						</table>
						<table cellpadding="0" cellspacing="0" class="es-content" align="center"
						style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%">
						<tr>
							<td align="center" bgcolor="#000" style="padding:0;Margin:0;background-color:#000000">
							<table bgcolor="#ffffff" class="es-content-body" align="center" cellpadding="0" cellspacing="0"
								style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#FFFFFF;width:600px">
								<tr>
								<td align="left" style="padding:0;Margin:0;padding-top:15px;padding-left:20px;padding-right:20px">
									<table cellpadding="0" cellspacing="0" width="100%"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
									<tr>
										<td align="center" valign="top" style="padding:0;Margin:0;width:560px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="center"
												style="padding:0;Margin:0;padding-top:10px;padding-bottom:10px;font-size:0px"><img
												src="https://pydxgs.stripocdn.email/content/guids/CABINET_c0e87147643dfd412738cb6184109942/images/151618429860259.png"
												alt
												style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"
												width="100" height="100"></td>
											</tr>
											<tr>
											<td align="center" style="padding:0;Margin:0;padding-bottom:10px">
												<h1
												style="Margin:0;line-height:46px;mso-line-height-rule:exactly;font-family:helvetica,  arial, verdana, sans-serif;font-size:46px;font-style:normal;font-weight:bold;color:#333333">
												Thanks for&nbsp;choosing us!</h1>
											</td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
								</td>
								</tr>
								<img src="" alt="">
							</table>
							</td>
						</tr>
						</table>
						<table cellpadding="0" cellspacing="0" class="es-content" align="center"
						style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%">
						<tr>
							<td align="center" style="padding:0;Margin:0">
							<table bgcolor="#ffffff" class="es-content-body" align="center" cellpadding="0" cellspacing="0"
								style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#FFFFFF;width:600px">
								<tr>
								<td align="left"
									style="Margin:0;padding-bottom:10px;padding-top:20px;padding-left:20px;padding-right:20px">
									<table cellpadding="0" cellspacing="0" width="100%"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
									<tr>
										<td align="center" valign="top" style="padding:0;Margin:0;width:560px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="center" class="es-m-p0r es-m-p0l"
												style="Margin:0;padding-top:5px;padding-bottom:5px;padding-left:40px;padding-right:40px">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Your order&nbsp;has now been confirmed!&nbsp;<br>We’ve attached <strong>a QR code 
												</strong>(receipt) to this email.</p>
											</td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
								</td>
								</tr>
								<tr>
								<td align="left"
									style="Margin:0;padding-bottom:10px;padding-top:20px;padding-left:20px;padding-right:20px">
									<!--[if mso]><table style="width:560px" cellpadding="0" cellspacing="0"><tr><td style="width:280px" valign="top"><![endif]-->
									<table cellpadding="0" cellspacing="0" class="es-left" align="left"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left">
									<tr>
										<td class="es-m-p0r es-m-p20b" align="center" style="padding:0;Margin:0;width:280px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="left" style="padding:0;Margin:0">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Customer: <strong>'."$full_name".'</strong></p>
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Order number:&nbsp;<strong>#'."$order_reference".'</strong></p>
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Ordered date:&nbsp;<strong>'."$ordered_date".'</strong></p>
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Payment method:&nbsp;<strong>Debit/Credit</strong></p>
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Currency:&nbsp;<strong>Indian Rupees</strong></p>
											</td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
									<!--[if mso]></td><td style="width:0px"></td><td style="width:280px" valign="top"><![endif]-->
									<table cellpadding="0" cellspacing="0" class="es-right" align="right"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right">
									<tr>
										<td class="es-m-p0r" align="center" style="padding:0;Margin:0;width:280px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="left" class="es-m-txt-l" style="padding:0;Margin:0">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Shipping Type: <strong>Standard</strong></p>
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Shipping address:</p>
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												<strong>'."$address".'</strong></p>
											</td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
									<!--[if mso]></td></tr></table><![endif]-->
								</td>
								</tr>
								<tr>
								<td align="left" style="padding:0;Margin:0;padding-top:20px;padding-left:20px;padding-right:20px">
									<!--[if mso]><table style="width:560px" cellpadding="0" cellspacing="0"><tr><td style="width:360px" valign="top"><![endif]-->
									<table cellpadding="0" cellspacing="0" class="es-left" align="left"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left">
									<tr>
										<td class="es-m-p0r es-m-p20b" valign="top" align="center"
										style="padding:0;Margin:0;width:360px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="left" style="padding:0;Margin:0">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												<strong>Products</strong></p>
											</td>
											</tr>
											<tr>
											<td align="left" style="padding:0;Margin:0">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												'."$list".'</p>
											</td>
											</tr>																															
										</table>
										</td>
									</tr>
									</table>
									<!--[if mso]></td><td style="width:20px"></td><td style="width:180px" valign="top"><![endif]-->
									<table cellpadding="0" cellspacing="0" align="right"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
									<tr>
										<td align="left" style="padding:0;Margin:0;width:180px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="right" class="es-m-txt-l" style="padding:0;Margin:0">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Subtotal:&nbsp;<strong>₹'."$temp_total".'</strong><br>Shipping: &nbsp;+<strong>₹'."$ship".'</strong><br>GST: &nbsp;+<strong>₹'."$cart_gst ".'</strong><br>Discount:-&nbsp;<strong>₹'."$cart_discount".'</strong><br><strong style="color:#ff7f50;">Total:&nbsp; ₹'."$g_total".'</strong>
												</p>
											</td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
									<!--[if mso]></td></tr></table><![endif]-->
								</td>
								</tr>
								<tr>
								<td align="left"
									style="Margin:0;padding-bottom:10px;padding-top:15px;padding-left:20px;padding-right:20px">
									<table cellpadding="0" cellspacing="0" width="100%"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
									<tr>
										<td align="left" style="padding:0;Margin:0;width:560px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="center" style="padding:20px;Margin:0;font-size:0">
												<table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0"
												role="presentation"
												style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
												<tr>
													<td
													style="padding:0;Margin:0;border-bottom:1px solid #cccccc;background:none;height:1px;width:100%;margin:0px">
													</td>
												</tr>
												</table>
											</td>
											</tr>
											<tr>
											<td align="center" style="padding:0;Margin:0;padding-top:10px;padding-bottom:10px">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:21px;color:#333333;font-size:14px">
												Got a question?&nbsp;Email us at&nbsp;<a target="_blank" href=""
													style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#ff7f50;font-size:14px">projectcovid2@gmail.com</a>&nbsp;or
												give us a call at&nbsp;<a target="_blank" href=""
													style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#ff7f50;font-size:14px">+000
													123 456</a>.</p>
											</td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
								</td>
								</tr>
							</table>
							</td>
						</tr>
						</table>
						<table cellpadding="0" cellspacing="0" class="es-footer" align="center"
						style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top">
						<tr>
							<td align="center" style="padding:0;Margin:0">
							<table class="es-footer-body" align="center" cellpadding="0" cellspacing="0"
								style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px">
								<tr>
								<td align="left"
									style="Margin:0;padding-top:5px;padding-bottom:5px;padding-left:20px;padding-right:20px">
									<table cellpadding="0" cellspacing="0" width="100%"
									style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
									<tr>
										<td align="left" style="padding:0;Margin:0;width:560px">
										<table cellpadding="0" cellspacing="0" width="100%" role="presentation"
											style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
											<tr>
											<td align="center"
												style="padding:0;Margin:0;padding-top:15px;padding-bottom:15px;font-size:0">
												<table cellpadding="0" cellspacing="0" class="es-table-not-adapt es-social"
												role="presentation"
												style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
												<tr>
													<td align="center" valign="top" style="padding:0;Margin:0;padding-right:40px"><img
														title="Facebook"
														src="https://pydxgs.stripocdn.email/content/assets/img/social-icons/logo-black/facebook-logo-black.png"
														alt="Fb" width="32" height="32"
														style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic">
													</td>
													<td align="center" valign="top" style="padding:0;Margin:0;padding-right:40px"><img
														title="Twitter"
														src="https://pydxgs.stripocdn.email/content/assets/img/social-icons/logo-black/twitter-logo-black.png"
														alt="Tw" width="32" height="32"
														style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic">
													</td>
													<td align="center" valign="top" style="padding:0;Margin:0"><img title="Instagram"
														src="https://pydxgs.stripocdn.email/content/assets/img/social-icons/logo-black/instagram-logo-black.png"
														alt="Inst" width="32" height="32"
														style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic">
													</td>
												</tr>
												</table>
											</td>
											</tr>
											<tr>
											<td style="padding:0;Margin:0">
												<table cellpadding="0" cellspacing="0" width="100%" class="es-menu"
												role="presentation"
												style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
												<tr class="links">
													<td align="center" valign="top" width="50%"
													style="Margin:0;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;border:0"
													id="esd-menu-id-0"><a target="_blank" href=""
														style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;font-family:arial,  helvetica, sans-serif;color:#333333;font-size:12px">Visit
														Us </a></td>
													<td align="center" valign="top" width="50%"
													style="Margin:0;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;border:0;border-left:1px solid #cccccc"
													id="esd-menu-id-1"><a target="_blank" href=""
														style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;font-family:arial,  helvetica, sans-serif;color:#333333;font-size:12px">Privacy
														Policy</a></td>
												</tr>
												</table>
											</td>
											</tr>
											<tr>
											<td align="center" style="padding:0;Margin:0;padding-bottom:5px;padding-top:10px">
												<p
												style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial,  helvetica, sans-serif;line-height:12px;color:#333333;font-size:12px">
												©2021 <span style="color:#ff7f50">C19-Covid-19.</span> All Rights Reserved.</p>
											</td>
											</tr>
										</table>
										</td>
									</tr>
									</table>
								</td>
								</tr>
							</table>
							</td>
						</tr>
						</table>
					</td>
					</tr>
				</table>
				</div>
			</body>
			</html>';

					$file_name = "admin/qrcodes/$order_reference.png";
                    $mail->addAttachment($file_name);

                    
                    
                    $subject = "Thank you for shopping.Your order as been confirmed.";
                    $mail->addAddress($email);
                    
                    // Content
                    $mail->isHTML(true);                                  // Set email format to HTML
                    $mail->Subject = $subject;
                    $mail->Body    = $html;
                
					if( $mail->send()){
						echo "<script>alert('Thank you for shopping.Your order as been confirmed. You will get a confirmation mail');</script>"; 
						echo "<script>window.location.href = 'shop.php'</script>"; 
						exit();
					}else{
						echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
						
					}
				
				
			}
		}

	}
?>


<!doctype html>
<html lang="en">

<head>
	<title>Covid - Checkout</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="images/favicon2.ico" type="image/x-icon">


	<link href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;700;900&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="fonts/icomoon/style.css">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<link rel="stylesheet" href="css/jquery.fancybox.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">

	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="fonts/flaticon-covid/font/flaticon.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/style.css">
	<style>
		.shop-card-shadow {
	border-radius: 6px;
	box-shadow: rgb(0 0 0 / 7%) 0px 0px 30px 0px;
	}
	</style>


</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


<!-- 	
	<div id="overlayer"></div>
	<div class="loader row flex-column align-items-center align-content-center">
		<div class="spinner-border text-primary" role="status"> </div>
		<h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
		<p class="mt-0">Loading...</p>
	</div> -->


	<div class="site-wrap">

		<!-- header -->
		<?php require "header.php";?>


		<div class="hero-v1 ">
			<div class="container">
				<div class="row align-items-center justify-content-center">
					<div class="col-lg-6 text-center mx-auto">
						<h1 class="heading mb-3 mt-3">Checkout</h1>
						<h2 class="mb-4 ">This is Checkout page</h2>

						<p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel a</p>
					</div>

				</div>
			</div>
		</div>


		<!-- MAIN -->

		<main class="skin-light mb-5 mt-5">
			<div class="container">

				<div class="row">
					<main class="col-md-8">

			<form action="" method="post">
						<article class="shop-card-shadow mb-5">
							<div class="card-body shop-card-shadow	">
								<h4 class="card-title mb-4">Contact info</h4>
								
									<div class="row">
										<div class="form-group col-sm-6">
											<label>Frst name</label>
											<input type="text" name="first_name" placeholder="eg. Hari" class="form-control" required >
										</div>
										<div class="form-group col-sm-6">
											<label>Last name</label>
											<input type="text" name="last_name" placeholder="eg. Krishna" class="form-control" required >
										</div>
										<div class="form-group col-sm-6">
											<label>Phone</label>
											<input type="text" name="phone_number"  placeholder="eg. 9345367236" class="form-control" required>
										</div>
										<div class="form-group col-sm-6">
											<label>Email</label>
											<input type="email" name="email" placeholder="example@gmail.com" class="form-control" required>
										</div>
									</div> <!-- row.// -->
									
							</div> <!-- card-body.// -->
						</article> <!-- card.// -->


						<article class="shop-card-shadow mb-5">
							<div class="card-body shop-card-shadow">
								<h4 class="card-title mb-4">Delivery info</h4>
								
									<div class="row">
										<div class="form-group col-sm-4">
											<label>Building Number</label>
											<input type="text" name="building_number" placeholder="eg. 12" class="form-control">
										</div>

										<div class="form-group col-sm-8">
											<label>Street*</label>
											<input type="text" name="street" placeholder="eg. 6th cross" class="form-control">
										</div>

										<div class="form-group col-sm-6">
											<label>Area*</label>
											<input type="text" name="area" placeholder="eg. Chikkabanavara" class="form-control">
										</div>

										<div class="form-group col-sm-6">
											<label>City*</label>
											<input type="text" name="city" placeholder="eg. Benagluru" class="form-control">
										</div>
										
										<div class="form-group col-sm-4">
											<label>Postal code</label>
											<input type="text" name="code" placeholder="eg. 560090" maxlength="6" minlength="6" class="form-control">
										</div>
										
									</div> <!-- row.// -->

							</div> <!-- card-body.// -->
						</article> <!-- card.// -->

						<div class="shop-card-shadow mb-5">
							<div class="card-body shop-card-shadow">
								<h4 class="card-title mb-4">Payment info</h4>
								<p>Please your credit/debit card for the purchase</p>

									<div class="form-group">
										<label >Name on card</label>
										<input type="text" class="form-control" name="name_on_card" placeholder="Ex. John Smith" required="">
									</div> <!-- form-group.// -->

									<div class="form-group">
										<label >Card number</label>
										<div class="input-group">
											<input type="text" class="form-control" name="card_number" minlength="12" maxlength="12" placeholder="2343 3546 2344" required>
											<div class="input-group-append">
												<span class="input-group-text">
													<i class="fab fa-cc-visa"></i> &nbsp; <i class="fab fa-cc-amex"></i>
													&nbsp;
													<i class="fab fa-cc-mastercard"></i>
												</span>
											</div>
										</div> <!-- input-group.// -->
									</div> <!-- form-group.// -->
									<div class="row">
										<div class="col-md flex-grow-0">
											<div class="form-group">
												<label><span class="hidden-xs">Expiration</span> </label>
												<div class="form-inline" style="min-width: 220px">
													<select name="MM" class="form-control" style="width:100px" required>
														<option selected disabled>MM</option>
														<option value="01">01 </option>
														<option value="02">02 </option>
														<option value="03">03 </option>
														<option value="04">04 </option>
														<option value="05">05 </option>
														<option value="06">06 </option>
														<option value="07">07 </option>
														<option value="08">08 </option>
														<option value="09">09 </option>
														<option value="10">10 </option>
														<option value="11">11 </option>
														<option value="12">12 </option>
													</select>
													<span style="width:20px; text-align: center"> / </span>
													<select name="YY" class="form-control" style="width:100px" required>
														<option selected disabled>YY</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
													</select>
												</div>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label data-toggle="tooltip" title="" data-original-title="3 digits code on back side of the card">CVV <i class="fa fa-question-circle"></i></label>
												<input class="form-control" name="cvv" required type="password" minlength="3" maxlength="3">
											</div> <!-- form-group.// -->
										</div>
									</div> <!-- row.// -->
								
							</div> <!-- card-body.// -->
						</div>
					

					</main> <!-- col.// -->
					<aside class="col-md-4">
						<div class="shop-card-shadow">
							<div class="card-body ">
								<h4 class="mb-3">Overview</h4>
								
								<dl class="dlist-align">
									<dt class="text-muted">Delivery type:</dt>
									<dd>Standart</dd>
								</dl>
								<dl class="dlist-align">
									<dt class="text-muted">Payment method:</dt>
									<i class="fa fa-credit-card" style="font-size: 30px;" aria-hidden="true"></i>
								</dl>

								<dl class="dlist-align">
									<dt class="text-muted">List of Products</dt>
									<?php  echo implode('<br>',$_SESSION['cart_items']); ?>
									
									
								</dl>
								<hr>
								<dl class="dlist-align">
									<dt>Total:</dt>
									<dd class="h5 myred">₹ <?php echo IND_money_format($_SESSION['grand_total'],2)?></dd>
								</dl>
								<hr>
								<p class="small mb-3 text-muted">Confirmation mail would be sent to your email address.<p>
								<!-- <a href="#" class="btn btn-primary btn-block" type="submit" name="confirm"> CONFIRM </a> -->
								<button type="submit" name="confirm" class="btn btn-primary btn-block font-weight-bold "> CONFIRM </button>

							</div> <!-- card-body.// -->
						</div> <!-- card.// -->
					</aside> <!-- col.// -->
				</div> <!-- row.// -->
			</form>	

			</div>
		</main>


		
	</div>
	<!-- footer -->
	<?php require "footer.php";?>

	</div> <!-- .site-wrap -->

	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.countdown.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.fancybox.min.js"></script>
	<script src="js/jquery.sticky.js"></script>
	<script src="js/isotope.pkgd.min.js"></script>


	<script src="js/main.js"></script>


</body>

</html>