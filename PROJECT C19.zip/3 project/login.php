<?php 

    require "connection.php";
    session_start();

    $email = "";
    $name = "";
    $errors = array();

    //if user click login button
    if (!isset($_SESSION['id']) ) {
        
        if(isset($_POST['login'])){
            $email = mysqli_real_escape_string($con, $_POST['email']);
            $password = mysqli_real_escape_string($con, $_POST['password']);
            $check_email = "SELECT * FROM usertable WHERE email = '$email'";
            $res = mysqli_query($con, $check_email);
            if(mysqli_num_rows($res) > 0){
                $fetch = mysqli_fetch_assoc($res);
                $fetch_pass = $fetch['password'];
                if(password_verify($password, $fetch_pass)){
                    // $_SESSION['email'] = $email;
                    $status = $fetch['status'];
                    if($status == 'verified'){
                        $_SESSION['email'] = $fetch['email'];
                        $_SESSION['user_name']= $fetch['name'];
                        $_SESSION['id'] = $fetch['id'];
                        // $_SESSION['password'] = $password;
                        $_SESSION['isLogin'] = true;
                        header('location: index.php');
                    }else{
                        $info = "It's look like you haven't still verified your email - $email";
                        $_SESSION['info'] = $info;
    
                        header('location: user-otp.php');
                    }
                }else{
                    $_SESSION['email'] = "";
    
                    $errors['email'] = "Incorrect  password!";
                }
            }else{
                $errors['email'] = "It's look like you're not yet a member! Click on the bottom link to signup.";
            }
        }
    }else {
        header('location: index.php');
    }
    


?>



<!doctype html>
<html lang="en">

<head>
    <title>Covid - Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/favicon2.ico" type="image/x-icon">

    <!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	
    <!-- Bootstrap CDN links -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/jquery.fancybox.min.css">
	<link rel="stylesheet" href="css/aos.css">

    <!-- Custom Style sheet -->
	<link rel="stylesheet" href="css/style.css">

    <!-- page specifi style sheet -->
    <style>
        .container .form {
            background: #fff;
            border-radius: 5px;
            margin-left: -20px;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.075), 0 6px 20px 0 rgba(0, 0, 0, 0.075);
;
        }

        .container .form form .form-control {
            height: 40px;
            font-size: 15px;
        }

        .container .form form .forget-pass {
            margin: -15px 0 15px 0;
        }

        .container .form form .forget-pass a {
            font-size: 15px;
        }

        .container .form form .button {
            background: #6665ee;
            color: #fff;
            font-size: 17px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .container .form form .button:hover {
            background: #5757d1;
        }

        .container .form form .link {
            padding: 5px 0;
        }

        .container .form form .link a {
            color: #FF4F5B;
        }

        .container .login-form form p {
            font-size: 14px;
        }

        .container .row .alert {
            font-size: 14px;
        }
    </style>
</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


    <div id="overlayer"></div>
	<div class="loader row flex-column align-items-center align-content-center">
        <div class="spinner-border text-primary" role="status"> </div>
        <h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
		<p class="mt-0">Loading...</p>
	</div>

    <div class="site-wrap">

        <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close ">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>


        <!-- header -->
        <?php require "header.php";?>



        <div class="site-section pb-5 ">
            <div class="container  bg-2 ">
                <div class="myrow ml-0 pl-0 mt-4">
                    <div class=" col-lg-4 col-md-6 login-section-wrapper pl-3 pr-3 pb-3 form login-form">
                        <form action="login.php" method="POST" autocomplete="">

                            <div>
                                <p class="span-red text-center">Welcome Back! <span> &nbsp; Login</span></p>
                            </div>
                            <form>

                                <?php
                                    if(count($errors) > 0){
                                        ?>
                                        <div class="alert alert-danger text-center">
                                            <?php
                                            foreach($errors as $showerror){
                                                echo $showerror;
                                            }
                                            ?>
                                        </div>
                                        <?php
                                    }
                                ?>

									<div class="form-group">
										<label  class="text-black">Email</label>
										<input name="email" class="form-control"  placeholder="ex. name@gmail.com" type="email" required value="<?php echo $email ?>" >
									</div> 

									<div class="form-group">
                                        <label  class="text-black">Password</label>
										<input class="form-control" name="password" placeholder="******" type="password" required>
									</div> 

									<div class="form-group">
                                        <!-- <a  href="forgot-password.php">Forgot Password</a> -->
									</div> <!-- form-group form-check .// -->
									<div class="form-group">
										<button type="submit" name="login" class="btn btn-primary btn-block font-weight-bold " value="login"> Login </button>
									</div> 
								</form>
                            <hr>
                            <p class="text-center">Not yet a member? <a style="color: #FF4F5B;" href="signup.php">Sign Up</a> here</p>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- footer -->
    <?php require "footer.php";?>

    </div> <!-- .site-wrap -->

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>


    <script src="js/main.js"></script>


</body>

</html>