<?php
    require 'connection.php';
    
    session_start();

    $user_id=$_SESSION['id'];

    $product_id=$_GET['p_id'];
    $name= $_GET['name'];
    $code = $_GET['code'];
    $price = $_GET['price'];
    $quantity = $_GET['quantity'];
    $image = $_GET['image'];
    $qty=1;
    $sub_total = $price * $qty;


    $add_to_cart_query="insert into user_items(user_id,product_id,name,code,price,image,quantity,qty,sub_total) values ('$user_id','$product_id','$name','$code','$price','$image','$quantity','$qty','$sub_total')";
    $add_to_cart_result=mysqli_query($con,$add_to_cart_query);
    
    if ($add_to_cart_result) {
        echo "<script>alert('Product Added to cart');</script>"; 
        echo "<script>window.location.href = 'shop.php'</script>"; 
    }
?>