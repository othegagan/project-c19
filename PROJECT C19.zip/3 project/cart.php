<?php 

    require "connection.php";
    session_start();
        
    $email = $_SESSION['email'];
    if($email == false){
        header('Location: login.php');
    }


    function IND_money_format($number){    	
		$decimal = (string)($number - floor($number));
		$money = floor($number);
		$length = strlen($money);
		$delimiter = '';
		$money = strrev($money);

		for($i=0;$i<$length;$i++){
			if(( $i==3 || ($i>3 && ($i-1)%2==0) )&& $i!=$length){
				$delimiter .=',';
			}
			$delimiter .=$money[$i];
		}

		$result = strrev($delimiter);
		$decimal = preg_replace("/0\./i", ".", $decimal);
		$decimal = substr($decimal, 0, 3);

		if( $decimal != '0'){
			$result = $result.$decimal;
		}

		return $result;
	}
    
?>




<!doctype html>
<html lang="en">

<head>
    <title>Covid - Cart</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/favicon2.ico" type="image/x-icon">

    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="fonts/flaticon-covid/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/mdb.ecommerce.min.css">
    <link rel="stylesheet" href="css/style.css">

    <style>
        .shop-card-shadow {
    border-radius: 6px;
    box-shadow: rgb(0 0 0 / 7%) 0px 0px 30px 0px;
    }
    </style>

</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


    <div id="overlayer"></div>
	<div class="loader row flex-column align-items-center align-content-center">
        <div class="spinner-border text-primary" role="status"> </div>
        <h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
		<p class="mt-0">Loading...</p>
	</div>

    <div class="site-wrap">

        <!-- header -->
        <?php require "header.php";?>


        <div class="hero-v1 ">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-lg-6 text-center mx-auto">
                        <h1 class="heading mb-3 mt-3">Cart</h1>
                        <h2 class="mb-4 ">This is cart page</h2>

                        <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel a</p>
                    </div>

                </div>
            </div>
        </div>


        <!-- MAIN -->

        <main class="skin-light">
            <div class="container">

                <!--Section: Block Content-->
                <section class="mt-5 mb-4">
                    
                    <!--Grid row-->
                    <div class="row">

                        <!--Grid column-->
                        <div class="col-lg-8">
                            <!-- code for clearing the cart  -->
                            <div class="col-lg-4 " >
                            <?php 
                                if(isset($_GET['delid'])){
                                    $rid=intval($_GET['delid']);
                                    $sql=mysqli_query($con,"delete from user_items where user_id=$rid");
                                    echo "<script>alert('Cart cleared');</script>"; 
                                    echo "<script>window.location.href = 'cart.php'</script>";     
                            }?> 
                
            <a href="cart.php?delid=<?php echo $_SESSION['id']?>" onclick="return confirm('Do you really want to empty the cart ?');" class="btn  text-grey btn-block mb-3"> Clear cart </a>
                            </div>
                            <!-- Card -->
                            <div class="mb-4 shop-card-shadow">
                                <div class="card-body shop-card-shadow">


                                <?php                       
                                    $id=$_SESSION['id'];
                                    $result=mysqli_query($con,"select * from user_items where user_id =$id");
                                ?>

                                <h5 class="mb-4" style="font-family: 'Montserrat', sans-serif;">
                                Cart (<span><?php echo mysqli_num_rows($result)." ";?></span>  items)</h5>

                                
                                
                                <?php                                 
                                    $id=$_SESSION['id'];
                                    $result=mysqli_query($con,"select * from user_items where user_id =$id");
                                    $total = 0;
                                    $row=mysqli_num_rows($result);
                                    $_SESSION['cart_items']=array();
                                    if($row>0){
                                        while ($row=mysqli_fetch_array($result)) {
                                        ?>
        
                                            <div class="row mb-4" >
                                                <div class="col-md-5 col-lg-3 col-xl-3">
                                                    <div class="view zoom overlay z-depth-1 rounded mb-3 mb-md-0">
                                                        <img class="img-fluid w-100" src="<?php echo $row['image']?>" alt="product">
                                                    </div>
                                                </div>
                                                <div class="col-md-7 col-lg-9 col-xl-9">
                                                    <div>
                                                        <div class="d-flex justify-content-between">
                                                            <div>
                                                                <h5><?php echo $row['name']?></h5>
                                                                <?php array_push($_SESSION['cart_items'],$row['name']);?>
                                                                    
                                                                <p>PRICE : ₹<?php echo $row['price']?> </p>
                                                                <small> Note: <?php echo $row['quantity']?></small>
                                                            </div>
                                                        </div>

                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <div>

                                                            <!-- Code for deletion -->
                                                                <?php 
                                                                    if(isset($_GET['delid']))
                                                                    {
                                                                        $rid=intval($_GET['delid']);
                                                                        $pid=intval($_GET['pid']);
                                                                        
                                                                        $sql=mysqli_query($con,"delete from user_items where user_id=$rid and product_id=$pid");
                                                                        echo "<script>alert('Product removed from the cart');</script>"; 
                                                                        echo "<script>window.location.href = 'cart.php'</script>";     
                                                                    } 
                                                                ?>
                                                                    
                                                                <a href="cart.php?delid=<?php echo $id?>&amp;pid=<?php echo ($row['product_id']);?>" type="button"
                                                                onclick="return confirm('Do you really want to delete ?');"
                                                                    class="card-link-secondary small text-uppercase text-danger mr-3">
                                                                    <i class="fas fa-trash-alt mr-1"></i> Remove item </a>
        
                                                            </div>
                                                            <p class="mb-0" style="font-size: 18px;">
                                                                <span> Sub Toatl: &nbsp;<strong>₹<?php echo $row['sub_total']?></strong></span></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="mb-3">
                                        
                                        <?php 
                                            $total = $total + $row['sub_total'];
                                        }
                                    }else {
                                        ?>
                                            <p style=" color:red;" colspan="8">Your Cart is EMPTY....! <a href="shop.php">Continue Shopping</a></p>
                                        <?php    
                                    }
                                ?>

                                    <br>
                                    <p class="text-purple mb-0"><i class="fas fa-info-circle mr-1"></i> Do not delay the
                                        purchase, adding items to your cart does not mean booking them.</p>
                                </div>
                            </div>
                            <!-- Card -->

                            <!-- Card -->
                            <div class=" mb-4 shop-card-shadow">
                                <div class="card-body shop-card-shadow">

                                    <h5 class="mb-4">Expected shipping delivery</h5>

                                    <?php 
                                            $query=mysqli_query($con,"select * from shipping");
                                            $rate=mysqli_fetch_array($query);
                                            $shipping_rate = $rate['shipping_rate'];
                                            $_SESSION['ship_charge'] = $shipping_rate;
                                            
                                        ?>

                                    <p class="mb-0"> <?php echo $rate['delivery_details']?></p>
                                </div>
                            </div>
                            <!-- Card -->

                            <!-- Card -->
                            <div class="shop-card-shadow mb-4">
                                <div class="card-body shop-card-shadow">

                                    <h5 class="mb-4">We accept</h5>
                                        <img   src="images/payments.png" >

                                </div>
                            </div>
                            <!-- Card -->

                        </div>
                        <!--Grid column-->

                        <!--Grid column-->
                        <div class="col-lg-4">

                            <!-- Card -->
                            <div class="shop-card-shadow mb-4">
                                <div class="card-body shop-card-shadow">

                                    <h5 class="mb-3">The total amount of</h5>

                                    <ul class="list-group list-group-flush" style="font-family:Arial, Helvetica, sans-serif;">
                                        <li
                                            class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 pb-0">
                                            Temporary amount  <span>₹ <?php echo IND_money_format($total)?></span>
                                            <?php $_SESSION['temp_total']=IND_money_format($total); ?>
                                        </li>

                                        <?php if ($total === 0) {
                                            $shipping_rate= 0;
                                        }?>
                                        <li
                                            class="list-group-item d-flex justify-content-between align-items-center px-0">
                                            Shipping Charges  <span>+ &nbsp; ₹ <?php echo $shipping_rate?></span>
                                        </li>

                                        <?php 
                                            $gst = $total*($rate['GST']/100);
                                            $_SESSION['cart_gst'] =$gst;
                                        ?>
                                        <li
                                            class="list-group-item d-flex justify-content-between align-items-center px-0 border-0">
                                            GST Rate(<?php echo $rate['GST']."%";?>)   <span> + &nbsp;₹ <?php echo $gst?></span>
                                        </li>

                                        <?php 
                                            if ($rate['discount']===0) {
                                                $discount=0;
                                            }
                                            $discount = $total*($rate['discount']/100);
                                            $_SESSION['cart_discount']=$discount;
                                        ?>
                                        <li
                                            class="list-group-item d-flex justify-content-between align-items-center px-0">
                                            Discount(<?php echo $rate['discount']."%";?>) <span> - &nbsp; ₹ <?php echo $discount?></span>
                                        </li>
                                        <li
                                            class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 mb-3">
                                            <div>
                                                <strong>The total amount of</strong>
                                                <strong>
                                                    <p class="mb-0">(including VAT)</p>
                                                </strong>
                                            </div>
                                            <?php 
                                                $grand_total = $total + $shipping_rate + $gst - $discount;
                                                $_SESSION['grand_total']= $grand_total;
                                            ?>
                                            <span class="myred"><strong>₹ <?php echo IND_money_format($grand_total)?></strong></span>
                                        </li>
                                    </ul>

                                    <a href="shop.php" class="btn  text-grey btn-block mb-3"> Continue Shopping </a>

                                    <a href="checkout.php" class="btn  text-white btn-block mb-3" style="background-color:#FF4F5B;"> Make purchase </a>

                                </div>
                            </div>
                            <!-- Card -->

                            <!-- Card -->
                            <div class="shop-card-shadow mb-4">
                                <div class="card-body shop-card-shadow">

                                    <a class="dark-grey-text d-flex justify-content-between" data-toggle="collapse"
                                        href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                        Add a discount code (optional)
                                        <span><i class="fas fa-chevron-down pt-1"></i></span>
                                    </a>

                                    <div class="collapse" id="collapseExample">
                                        <div class="mt-3">
                                            <div class="md-form md-outline mb-0">
                                                <input type="text" id="discount-code"
                                                    class="form-control font-weight-light"
                                                    placeholder="Enter discount code">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Card -->

                        </div>
                        <!--Grid column-->

                    </div>
                    <!--Grid row-->

                </section>
                <!--Section: Block Content-->

            </div>
        </main>

    </div>
    <!-- footer -->
    <?php require "footer.php";?>

    </div> <!-- .site-wrap -->

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>


    <script src="js/main.js"></script>


</body>

</html>