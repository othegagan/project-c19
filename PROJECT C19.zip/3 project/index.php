<?php 
	require 'connection.php';
	session_start();

	function IND_money_format($number){    	
		$decimal = (string)($number - floor($number));
		$money = floor($number);
		$length = strlen($money);
		$delimiter = '';
		$money = strrev($money);

		for($i=0;$i<$length;$i++){
			if(( $i==3 || ($i>3 && ($i-1)%2==0) )&& $i!=$length){
				$delimiter .=',';
			}
			$delimiter .=$money[$i];
		}

		$result = strrev($delimiter);
		$decimal = preg_replace("/0\./i", ".", $decimal);
		$decimal = substr($decimal, 0, 3);

		if( $decimal != '0'){
			$result = $result.$decimal;
		}

		return $result;
	}
?>
<!doctype html>
<html lang="en">

<head>
	<title>Covid-19. - Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/favicon2.ico" type="image/x-icon">


    <!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	
    <!-- Bootstrap CDN links -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/jquery.fancybox.min.css">
	<link rel="stylesheet" href="css/aos.css">

    <!-- Custom Style sheet -->
	<link rel="stylesheet" href="css/style.css">

</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


	<div id="overlayer"></div>
	<div class="loader row flex-column align-items-center align-content-center">
        <div class="spinner-border text-primary" role="status"> </div>
        <h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
		<p class="mt-0">Loading...</p>
	</div>


	<div class="site-wrap">

		<!-- header -->
		<?php require "header.php"; ?>



		<div class="hero-v1 ">
			<div class="container">
				<div class="row align-items-center">

					<div class="col-lg-6 col-md-6 col-sm-6 mr-auto text-center text-lg-left">
						<span class="d-block subheading mt-3 beep">Covid-19 Awareness</span>
						<h1 class="heading mb-3"> Stay Safe. <br> Stay Healthy.</h1>
						<p class="mb-5"> Each day we hear about more people testing positive for covid-19 in our country recent studies suggest COVID-19 may be spread by people who show no symptoms.!</p>
						<p class="mb-4"><a href="vaccination.php" class="btn btn-primary">Vaccination</a></p>
					</div>

					<div class="col-lg-6 col-md-6 col-sm-6 col-12">
						<img src="images/home-img2.png" alt="Image" class="img-fluid">
					</div>
				</div>
			</div>
		</div>


		<!-- MAIN -->

		<div class="site-section stats">
			<div class="container">
				<div class="row mb-3">
					<div class="col-lg-7 text-center mx-auto mylink">
						<h2 class="section-heading">Coronavirus Statistics</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet, voluptate!</p>
						<a class="font-weight-bold text-primary" href="state_wise_details.php">View statewise details &nbsp;
							<i class="fas fa-arrow-right"></i></a>
					</div>
				</div>

				<?php

					$data = file_get_contents('https://api.covid19india.org/data.json');
					$coranalive = json_decode($data, true);

					$statescount = count($coranalive['statewise']);
					$i = 0;
					$active = $coranalive['statewise'][$i]['active'];
					$confirmed = $coranalive['statewise'][$i]['confirmed'];
					$deaths = $coranalive['statewise'][$i]['deaths'];
					$updated_time = $coranalive['statewise'][$i]['lastupdatedtime'];
					$recovered =$coranalive['statewise'][$i]['recovered'];

				?>



				<div class="row" style="font-size: 14px;">

					<div class="col-sm-4 ">
						<div class="stat-card ">
							<div class="stat-card__content">
								<p class="text-uppercase mb-2 font-weight-normal">COUNTRY</p>
								<div>
									<h1 class="text-success font-weight-bold ">INDIA</h1>
								</div>
							</div>
						</div>
					</div>

					<div class="col-sm-4 ">
						<div class="stat-card">
							<div class="stat-card__content">
								<p class="text-uppercase mb-2 font-weight-normal">ACTIVE</p>
								<div>
									<h1 class="text-primary font-weight-bold"><?php echo  IND_money_format($active) ?></h1>
								</div>
							</div>
						</div>
					</div>

					<div class="col-sm-4 ">
						<div class="stat-card">
							<div class="stat-card__content">
								<p class="text-uppercase mb-2 font-weight-normal">CONFIRMED</p>
								<div>
									<h1 class="text-warning font-weight-bold">  <?php echo IND_money_format($confirmed)  ?> </h1>
								</div>
							</div>
						</div>
					</div>

					<div class="col-sm-4 ">
						<div class="stat-card">
							<div class="stat-card__content">
								<p class="text-uppercase mb-2 font-weight-normal">DEATHS</p>
								<div>
									<h1 class="text-secondary font-weight-bold"> <?php echo IND_money_format($deaths) ?> </h1>
								</div>
							</div>
						</div>
					</div>

					<div class="col-sm-4 ">
						<div class="stat-card pr-0">
							<div class="stat-card__content">
								<p class="text-uppercase mb-2 font-weight-normal">LAST UPDATED TIME</p>
								<div>
									<h1 class=" text-purple font-weight-bold "> <?php echo $updated_time ?> </h1>
								</div>
							</div>
						</div>
					</div>

					<div class="col-sm-4 ">
						<div class="stat-card">
							<div class="stat-card__content">
								<p class="text-uppercase mb-2 font-weight-normal">RECOVERED</p>
								<div>
									<h1 class="text-success font-weight-bold"> <?php echo IND_money_format($recovered) ?> </h1>
								</div>
							</div>
						</div>
					</div>


				</div>
			</div>
		</div>

		<!-- shop -->

		<div class="site-section pt-0 pb-0" style=" background-color:rgba(133, 133, 133, 0.1);">
			<div class="container pb-0">
				<div class="row align-items-center ">
					<div class="col-lg-6 col-md-6 col-sm-6  ">
						<img src="images/do-img.png" alt="Image" style="height: 60%; width:100%; ">
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 ">
						<h2 class="mb-4 section-heading">Shop exclusive medicenes</h2>
						<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex officia quas, modi sit eligendi
							numquam!</p>
							<div class="font-weight-bold mb-md-3 mb-lg-5">
								<p class="mb-0"> <i class="fad fa-check-circle " style="color: orange;"></i> Lorem ipsum dolor sit amet, consectetu</p>								
								<p class="mb-0"> <i class="fad fa-check-circle " style="color: orange;"></i> Lorem ipsum dolor sit amet, consectetu</p>								
								<p class="mb-0"> <i class="fad fa-check-circle " style="color: orange;"></i> Lorem ipsum dolor sit amet, consectetu</p>								
							</div>
						
						<p><a href="shop.php" class="btn btn-primary">Shop now</a></p>
					</div>
				</div>
			</div>
		</div>



		<div class="site-section">
			<div class="container">
				<div class="row ">
					<div class="col-lg-7 mx-auto text-center">
						<span class="subheading">What you need to do?</span>
						<h2 class="mb-4 section-heading">How To Protect Yourself</h2>
						<p>Prevention is better than having the virus itself!</p>
					</div>
				</div>
				<div class="row align-items-center">
					<div class="col-lg-6 ">
						<div class="row  ">
							<div class="col-lg-6 col-md-6 col-sm-6  mb-4 align-items-center ">
								<h4 style="color: limegreen;" class="mb-4"> <i class="fal fa-ballot-check"></i>  You should do :) </h4>
								<div>
									<p><i class="fal fa-check mb-0"  style="color:limegreen;"></i> Stay at home</p>
									<p><i class="fal fa-check" style="color:limegreen;"></i> Wear mask</p>
									<p><i class="fal fa-check" style="color:limegreen;"></i> Use Sanitizer</p>
									<p><i class="fal fa-check" style="color:limegreen;"></i> Disinfect your home</p>
									<p><i class="fal fa-check" style="color:limegreen;"></i> Wash your hands</p>
									<p><i class="fal fa-check" style="color:limegreen;"></i> Frequent self-isolation</p>
								</div>

							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 align-items-center">
								<h4 style="color:crimson;" class="mb-4"><i class="fal fa-ballot-check"></i>  You should avoid :(</h4>
								<div>
									<p><i class="fal fa-times" style="color: crimson;"></i> &nbsp; Avoid infected people</p>
									<p><i class="fal fa-times" style="color: crimson;"></i> &nbsp; Avoid animals</p>
									<p><i class="fal fa-times" style="color: crimson;"></i> &nbsp; Avoid handshaking</p>
									<p><i class="fal fa-times" style="color: crimson;"></i> &nbsp; Aviod infected surfaces</p>
									<p><i class="fal fa-times" style="color: crimson;"></i> &nbsp; Don't touch your face</p>
									<p><i class="fal fa-times" style="color: crimson;"></i> &nbsp; Avoid droplets</p>

								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<img src="images/protect.png" alt="Image" class="img-fluid">
					</div>
				</div>
			</div>
		</div>

		<!-- symptoms -->
		<div class="site-section " style=" background-color:rgba(133, 133, 133, 0.1);">
			<div class="container">
				<div class="row mb-5">
					<div class="col-lg-7 mx-auto text-center">
						<h2 class="mb-4 section-heading">Symptoms of Coronavirus</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex officia quas, modi sit eligendi
							numquam!</p>
					</div>
				</div>


				<div class="row justify-content-md-center">
					<div class="col-lg-10">
						<div class="note row">

							<div class="col-lg-8 mb-4 mb-lg-0"><strong>Stay at home and call your doctor:</strong> Lorem
								ipsum
								dolor
								sit amet, consectetur adipisicing elit. Accusantium, eaque.</div>
							<div class="col-lg-4 text-lg-right">
								<a href="#" class="btn btn-primary"><span class="icon-phone mr-2 mt-3"></span>Help
									line</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>





		<!-- footer -->
		<?php require "footer.php"; ?>
	</div> <!-- .site-wrap -->

	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.countdown.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.fancybox.min.js"></script>
	<script src="js/jquery.sticky.js"></script>
	<script src="js/isotope.pkgd.min.js"></script>


	<script src="js/main.js"></script>


</body>

</html>