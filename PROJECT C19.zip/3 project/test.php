<?php
    require 'connection.php';
    
    session_start();
    if(isset($_GET['delid']))
    {
        $rid=intval($_GET['delid']);
        $sql=mysqli_query($con,"delete from user_items where user_id=$rid");
        echo "<script>alert('Data deleted');</script>"; 
        echo "<script>window.location.href = 'cart.php'</script>";     
    } 

?>

