<?php 

    require "connection.php";
    session_start();
        
    $email = $_SESSION['email'];
    if($email == false){
        header('Location: login.php');
    }

    // to check if product as been added to cart already
    function check_if_added_to_cart($p_id){
        require 'connection.php';
        //session_start();    
        $user_id=$_SESSION['id'];
        $product_check_query="select * from user_items where product_id='$p_id' and user_id='$user_id'";
        $product_check_result=mysqli_query($con,$product_check_query) or die(mysqli_error($con));
        $num_rows=mysqli_num_rows($product_check_result);
        if($num_rows>=1)return true;
        return false;
    }
    
?>


<!doctype html>
<html lang="en">

<head>
    <title>Covid - Shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/favicon2.ico" type="image/x-icon">


    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="fonts/flaticon-covid/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <!-- <link rel="stylesheet" href="css/mdb-pro.min.css"> -->
    <link rel="stylesheet" href="css/mdb.ecommerce.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        @media (min-width: 992px){
            .col-lg-4 {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 33.33333%;
                flex: 0 0 33.33333%;
                max-width: 29.33333%;
            }
        }
    </style>

    </style>
</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


    <div id="overlayer"></div>
    <div class="loader row flex-column align-items-center align-content-center">
        <div class="spinner-border text-primary" role="status"> </div>
        <h1 class="font-weight-bolder col-md-12" style="font-size: 75px; color: #ff4f5b29;"> C-19</h1>
        <p class="mt-0">Loading...</p>
    </div>

    <div class="site-wrap">

        <!-- header -->
        <?php require "header.php"; ?>


        <div class="hero-v1 ">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-lg-6 text-center mx-auto">
                        <h1 class="heading mb-3 mt-3">Shop</h1>
                        <p class="mb-4 ">Buy the exclusive mediece/immune boosters/ equipments avaliable right now!</p>
                    </div>

                </div>
            </div>
        </div>

    <!-- MAIN -->
        
        <div class="site-section ">
            <div class="container">
                <div class="row justify-content-between">
                <?php
                    require "connection.php";
                    $show =mysqli_query($con,"SELECT * from products");
                    while ($row = mysqli_fetch_array($show)):
                ?>

                    <div class="col-sm-6 col-md-6 col-lg-4 mb-5  mr-lg-2 shop-card-shadow ">
                        <div class="post-entry pt-1">

                            <img src="<?php  echo $row['product_file'];?>" alt="Image" class="img-fluid">
                            
                            <div class="row  p-3 justify-content-between">
                                <h5><?php  echo $row['product_name'];?></h5> <br>
                                
                                <div class="row pl-3 pr-3 mb-0 justify-content-between">
                                    
                                    <h4 class="text-primary"><strong>₹<?php  echo $row['product_price'];?></strong> &nbsp; &nbsp;</h4> 
                                    <p class="mb-1 mt-0"><?php  echo $row['product_quantity'];?></p>
                                </div>

                                <p style="text-align:left"> <?php  echo $row['product_description'];?> </p>

                                <?php 
                                    if(check_if_added_to_cart($row['p_id'])){
                                        ?><a href="#" class="btn btn-primary btn-block disabled"> Add to Cart <i class="fas fa-shopping-cart"></i> </a>  <?php  
                                    }else{
                                        ?> 
                                            <a href="add_to_cart.php?p_id=<?php echo ($row['p_id']);?>&amp;name=<?php echo ($row['product_name']);?>&amp;code=<?php echo ($row['product_code']);?>&amp;price=<?php echo ($row['product_price']);?>&amp;quantity=<?php echo ($row['product_quantity']);?>&amp;image=<?php echo ($row['product_file']);?>" class="btn btn-primary btn-block "> Add to Cart <i class="fas fa-shopping-cart"></i> </a>    
                                        <?php
                                        }
                                
                                
                                
                                ?>
                            </div>
                        </div>
                    </div>

                <?php endwhile; ?>
                </div>
            </div>
        </div> <!-- .site-wrap -->
    


        <!-- footer -->
        <?php require "footer.php"; ?>


    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>


    <script src="js/main.js"></script>


</body>

</html>