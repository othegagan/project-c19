
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<style>
    li a:hover{
        font-weight: 500;
        color:#FF4F5B;
        
    }
</style>


<nav class="navbar navbar-expand-lg navbar-light bg-light site-navbar js-sticky-header ">
    <div class="container">
        <div class="mb-0 site-logo"><a href="index.php" class="mb-0">C<span
                    class="myred fas fa-virus"></span>vid-19<span class="myred">.</span> </a></div>
        <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"
            style="color: rgb(0 0 0 / 60%); border-color:#ffffff00;">
            <span><i class="fa fa-bars" aria-hidden="true"></i></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto ">
                
                
                <!-- if user as not logged in -->
                <?php 
                    if (!isset($_SESSION['id'])) {
                        ?>
                            <li class="nav-item mr-3 ">
                                <a class="nav-link" href="index.php">Home</a>
                            </li>

                            <li class="nav-item mr-3">
                                <a href="login.php" class="nav-link">Login</a>
                            </li>

                            <li class="nav-item mr-3">
                                <a href="signup.php" class="nav-link">SignUp</a>
                            </li>

                        <?php
                    }
                ?>

    <!-- ************************************************************************************************* -->

                <!-- if user as logged in -->
                <?php    
                        
                    if (isset($_SESSION['id']) && isset($_SESSION['email']) ) {
                        ?>
                            <li class="nav-item mr-3 ">
                                <a class="nav-link" href="index.php">Home</a>
                            </li>

                            <li class="nav-item mr-3">
                                <a href="shop.php" class="nav-link">Shop</a>
                            </li>

                            <?php     
                                if(isset($_SESSION['id'])){
                                    $id=$_SESSION['id'];
                                    $result=mysqli_query($con,"select * from user_items where user_id =$id");

                                    ?> 
                                    <li class="nav-item mr-3 ">
                                        <a href="cart.php" class="nav-link ">Cart(<?php echo mysqli_num_rows($result);?>)</a>
                                    </li>
                                    <?php
                                }
                            ?>
                            <li class="nav-item mr-3">
                                <a href="logout.php" class="nav-link myred">Logout</a>
                            </li>
                        <?php
                    } 
                ?>


        </div>
    </div>
</nav>