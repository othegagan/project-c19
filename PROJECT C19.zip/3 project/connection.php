<?php 
$con = mysqli_connect('localhost', 'root', '', 'c19') or die("Connection Error: " . mysqli_error($con));
?>
