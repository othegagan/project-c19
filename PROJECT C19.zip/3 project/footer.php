
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	
<style>
		#footer {
			position: relative;
			margin-bottom: 0;
            clear: both;
			width: 100%;
			height: 100%;
		}
	</style>

<div class="site-footer text-white pb-1" id="footer">
    <div class="container">
        <div class="row">

            <div class="col-lg-4 col-md-4 col-12 mb-2">
                <h3 class="footer-heading mb-3"> Contact Us</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi cumque tenetur inventore
                    veniam, hic vel ipsa necessitatibus ducimus architecto fugiat!</p>
                <div class="my-3 mb-2 share">
                    <p><i class="fas fa-phone myred " style="font-size: 18px;"></i> &nbsp; <a href="tel:+919036644552" style="font-size:18px;">9036644552</a>, &nbsp;<a href="tel:+919141167512"style="font-size:18px;">919141167512</a></p>
                    
                </div>
            </div>

            <div class="col-lg-2 col-md col-6 mb-2">
                <h3 class="footer-heading mb-4">Quick Links</h3>
                <ul class="list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="#">FAQs</a></li>
                    <li><a href="#">About Coronavirus</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md col-6 mb-2">
                <h3 class="footer-heading mb-4">Helpful Link</h3>
                <ul class="list-unstyled">
                    <li><a href="#">Helathcare </a></li>
                    <li><a href="#">LGU Facilities</a></li>
                    <li><a href="#">Protect Your Family</a></li>
                    <li><a href="#">World Health</a></li>
                </ul>
            </div>

            <div class="col-lg-4 col-md-4 col-12 mb-4">
                <h3 class="footer-heading mb-3"> About Us</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi cumque tenetur inventore
                    veniam, hic vel ipsa necessitatibus ducimus architecto fugiat!</p>
                <div class="my-3 mb-2 share myred">

                    <a href="#" class="pl-0 pr-3"><i class="fab fa-github myred"></i></a>
                    <a href="#" class="pl-3 pr-3"><i class="fab fa-facebook-f myred"></i></a>
                    <a href="#" class="pl-3 pr-3"><i class="fab fa-twitter myred"></i></a>
                    <a href="#" class="pl-3 pr-3"><i class="fab fa-instagram myred"></i></a>
                    <a href="#" class="pl-3 pr-3"><i class="fab fa-linkedin-in myred"></i></a>
                </div>
            </div>

        </div>

        <div class="text-center align-items-center mb-3">
            <div class="mb-3">
                <div class="border-top mb-3  pt-1">
                    <p class="copyright text-white mb-1">
                        &copy;<script>
                            document.write(new Date().getFullYear());
                        </script>  <a target="_blank" href="admin/admin_login.php"><span>C19-Covid-19.</span></a> All Rights Reserved.
                    </p>
                </div>
            </div>
        </div>

    </div>
</div>