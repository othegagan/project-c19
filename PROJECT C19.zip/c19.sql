-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2021 at 07:26 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `c19`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE `admintable` (
  `a_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_unq_id` varchar(50) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`a_id`, `admin_name`, `admin_unq_id`, `admin_email`, `admin_password`) VALUES
(4, 'Gagan Kumar', 'admin10866', 'gagankumar8711@gmail.com', '$2y$10$qXiLEtulaNltFNtyZBT4I.TsExLulL3uDNAquFlUojO7zjwDOjbO.'),
(5, 'Nithin G', 'admin10392', 'nithin06graj@gmail.com', '$2y$10$UDmfGd/X/NK9i5zhdKzPBull5x0BaDmGOSL6piLNhnP3kedk5mzEi');

-- --------------------------------------------------------

--
-- Table structure for table `id_card_type`
--

CREATE TABLE `id_card_type` (
  `id_card_type_id` int(10) NOT NULL,
  `id_card_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `id_card_type`
--

INSERT INTO `id_card_type` (`id_card_type_id`, `id_card_type`) VALUES
(1, 'Addhar Card'),
(2, 'Voter Id Card'),
(3, 'Pan Card'),
(4, 'Driving License');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `o_id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `card_number` varchar(20) NOT NULL,
  `product_list` text NOT NULL,
  `total_amount` varchar(50) NOT NULL,
  `ordered_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_status` enum('not done','done') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `order_id`, `name`, `phone_number`, `email`, `address`, `card_number`, `product_list`, `total_amount`, `ordered_date`, `order_status`) VALUES
(1, '7471123', 'Gagan  Kumar', '9036644552', 'gkmagics2018@gmail.com', '12 6th cross Chikkabanavara Bengalurur 247612', '937357640242', 'Digital Thermometer                ,Crocin 650 Fast release,Remdesivir Injection', '6831.19', '2021-08-15 12:06:58', 'done'),
(3, '9581936', 'Robin  Hood', '2357683524', 'robin@gmail.com', '54 34678fdhbsfgb dfhgfbjcvbuksj kjhagoifnadj 943689', '328954834534', 'Jeeni Millet Mix Powder ,Zinc Tablets (50mg)', '1290.73', '2021-08-16 04:56:56', 'done'),
(5, '7359285', 'Gagan  Kumar', '9036644552', 'gagankumar8711@gmail.com', '12 6th cross Chikkabanavara Bengalurur 560090', '512312356126', 'Digital Thermometer                 ,Crocin 650 Fast release', '704.21', '2021-08-17 17:06:19', 'not done'),
(6, '8752722', 'Gagan  Kumar', '9036644552', 'gagankumar8711@gmail.com', '12 6th cross Chikkabanavara Bengalurur 560090', '512312356126', 'Digital Thermometer                 ,Crocin 650 Fast release', '704.21', '2021-08-17 17:09:03', 'not done'),
(7, '2730055', 'Gagan  Kumar', '9036644552', 'gagankumar8711@gmail.com', '12 6th cross Chikkabanavara Bengalurur 560090', '512312356126', 'Digital Thermometer                 ,Crocin 650 Fast release', '704.21', '2021-08-17 17:11:36', 'not done'),
(8, '1898089', 'Gagan  Kumar', '9036644552', 'gagankumar8711@gmail.com', '12 6th cross Chikkabanavara Bengalurur 560090', '512312356126', 'Digital Thermometer                 ,Crocin 650 Fast release', '704.21', '2021-08-17 17:12:56', 'not done');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` varchar(20) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_description` text NOT NULL,
  `product_file` text NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `product_code`, `product_name`, `product_quantity`, `product_price`, `product_description`, `product_file`, `added_date`) VALUES
(1, 'C190001  ', 'Paracetamol Dolo 650mg      ', '(15 tablets)   ', '59', 'Dolo 650 Tablets  reduces headaches, body aches, and the common cold. It is recommended aftet taking the vaccine dose.  It works by release of certain chemicals that cause pain.       ', 'images/products/Dolo_650.jpg', '2021-08-12 14:39:05'),
(2, 'C190002    ', 'Digital Thermometer                 ', '(1 Peice)   ', '485', 'A Digital Thermometer, a numerical reading is given on a small screen, usually to one decimal place, which would be very useful in knowing the temperature when needed.    ', 'images/products/Digital_therometer.jpg', '2021-08-16 04:58:08'),
(3, 'C190003 ', 'Crocin 650 Fast release', '(15 tablets) ', '32', 'Crocin 650 a fever-reducing agent used to treat mild to moderate pain including headache, migraine, musculoskeletal pain, and reducing fever, which would be the primary aid. ', 'images/products/Crocin_650.jpg', '2021-08-12 14:41:43'),
(4, 'C190004 ', 'Jeeni Millet Mix Powder ', '(1 KG)', '369', 'Jeeni Millet Mix is power packed with protein, antioxidants, and nutrients. It may have numerous health benefits, such as helping lower your blood sugar and boosting the immunity. ', 'images/products/Jeeni_health_mix.jpg', '2021-08-12 14:44:49'),
(5, 'C190005', 'Digital Pulse Oximeter ', '(1 Peice)', '1998', 'Pulse oximetry is a test used to measure the oxygen level of the blood. It is an easy, painless measure of how well oxygen is being sent to parts of your body.', 'images/products/Pulse Oximeter.jpg', '2021-08-12 14:46:45'),
(6, 'C190006', 'Zinc Tablets (50mg)', '(10 tablets)', '370', 'Zinc supplements, above the recommended dietary allowance for the prevention of COVID-19.Check with your doctor before starting supplement.', 'images/products/Zinc_tablets.jpg', '2021-08-12 14:50:53'),
(7, 'C190007', 'Vitamin D-3 Capsules', '(180 Tablets)', '560', 'Vitamin D-3 is a fat-soluble vitamin that helps your body absorb calcium and phosphorus. Having the right amount of vitamin D is important for  maintaing a good immunity.', 'images/products/Vitamin_D-3.jpg', '2021-08-12 15:37:09'),
(8, 'C190008', 'Himalaya Hand Sanitizer', 'Pack of 5)', '270', 'Himalaya Hand Sanitizer is an  alcohol-based hand sanitizer, formulated with the goodness of time-tested herbs. It kills 99.9% of germs, helps prevent virus.', 'images/products/Sanitizers.jpg', '2021-08-12 15:40:46'),
(9, 'c190009', 'Remdesivir Injection', '(100 mg)', '5400', 'Remdesivir is antivirals. It works by stopping the virus from spreading in the body. A doctor or nurse should monitor you carefully while you are receiving the medication. ', 'images/products/Remdisivr.jpg', '2021-08-12 15:41:51');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `shipping_id` int(11) NOT NULL,
  `shipping_rate` int(50) NOT NULL,
  `GST` int(50) NOT NULL,
  `discount` int(50) NOT NULL,
  `delivery_details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`shipping_id`, `shipping_rate`, `GST`, `discount`, `delivery_details`) VALUES
(1, 120, 18, 5, 'You will get the product as fast as possible');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` mediumint(50) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `password`, `code`, `status`) VALUES
(2, 'Gagan Kumar', 'petonal902@100xbit.com', '$2y$10$l6is.iqrv3fSZFyXbNqO/.aBQldBKqzRM8rT0xzcdI5jZl0.YaLcW', 900420, 'notverified'),
(3, 'harry', 'harry@code.com', '$2y$10$5JD7SfdjtSXiUVpXgVHZW.psPdPgWe383VxrQEVtko/tp/US3TnMG', 0, 'verified'),
(14, 'Robin', 'rowibe1663@cfcjy.com', '$2y$10$vraYVU/2GVbAzS/jpOidtOtapOpjFzfWgYLwee7UB7hcZsMnVvbja', 0, 'verified'),
(20, 'Gagan Kumar', 'kefedon189@hax55.com', '$2y$10$4tYLt.88PRuoqnqnKEhpme9y3YyboiUDWGBlsZS5RgtsrufZPAP/.', 0, 'verified'),
(33, 'tri', 'trivedi8711@gmail.com', '$2y$10$J/aNPgM6KnHza3nLKe9DuOVY1Z.Y5w4D1gQF6CgqUzfg5KLay8mSS', 872827, 'notverified');

-- --------------------------------------------------------

--
-- Table structure for table `user_items`
--

CREATE TABLE `user_items` (
  `user_items_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(255) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(50) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `image` text NOT NULL,
  `qty` int(255) NOT NULL,
  `sub_total` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `vaccination`
--

CREATE TABLE `vaccination` (
  `v_id` int(11) NOT NULL,
  `reference_id` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `gender` enum('Male','Female','Others') NOT NULL,
  `age` int(3) NOT NULL,
  `contact_number` varchar(14) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `id_card_type` enum('Addhar Card','Voter ID','Pan card','Driving Licence') NOT NULL,
  `id_card_number` varchar(255) NOT NULL,
  `date` text NOT NULL,
  `slot_timings` enum('10am - 11am','11am - 12pm','12pm - 1pm','3pm - 4pm','4pm - 5pm') NOT NULL,
  `code` mediumint(50) NOT NULL,
  `status` enum('Not Verified','Verified') NOT NULL,
  `vaccie_status` enum('Vaccine not Done','Finished') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vaccination`
--

INSERT INTO `vaccination` (`v_id`, `reference_id`, `full_name`, `gender`, `age`, `contact_number`, `email_id`, `id_card_type`, `id_card_number`, `date`, `slot_timings`, `code`, `status`, `vaccie_status`) VALUES
(21, '82044537', 'Iron man', 'Male', 54, '566754342', 'hehas46633@697av.com', 'Addhar Card', '89658436478697', '2021-08-26', '3pm - 4pm', 0, 'Verified', 'Finished'),
(23, '45623453', 'Testing', 'Female', 34, '987654321', 'testing@gmail.com', 'Addhar Card', '34567896754', '12/08/2021', '3pm - 4pm', 0, 'Verified', 'Finished'),
(27, '41581408', 'favd', 'Male', 31, '4567589323', 'jerison.schneur@zooape.net', 'Addhar Card', '3456784755', '2021-08-19', '11am - 12pm', 0, 'Verified', 'Finished'),
(33, '92477749', 'Trivedi', 'Male', 18, '904342334', 'trivedi8711@gmail.com', 'Voter ID', '378456476', '2021-08-20', '12pm - 1pm', 0, 'Verified', 'Vaccine not Done');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintable`
--
ALTER TABLE `admintable`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `id_card_type`
--
ALTER TABLE `id_card_type`
  ADD PRIMARY KEY (`id_card_type_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_items`
--
ALTER TABLE `user_items`
  ADD PRIMARY KEY (`user_items_id`);

--
-- Indexes for table `vaccination`
--
ALTER TABLE `vaccination`
  ADD PRIMARY KEY (`v_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admintable`
--
ALTER TABLE `admintable`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `id_card_type`
--
ALTER TABLE `id_card_type`
  MODIFY `id_card_type_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `shipping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `user_items`
--
ALTER TABLE `user_items`
  MODIFY `user_items_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `vaccination`
--
ALTER TABLE `vaccination`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
